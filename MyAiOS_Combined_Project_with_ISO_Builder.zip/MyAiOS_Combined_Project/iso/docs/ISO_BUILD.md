# MyAi OS Bootable ISO Builder (One Command)

This uses **Docker** to run Debian **live-build** and outputs an ISO.

## Build (Linux)
```bash
chmod +x iso/scripts/build_iso.sh
./iso/scripts/build_iso.sh
```

## Build (Windows)
Requirements: Docker Desktop + WSL2
```powershell
.\iso\scripts\build_iso.ps1
```

## Output
`iso/out/MyAiOS-livebookworm-amd64.iso`

## What’s inside the ISO
- Debian Bookworm live system (amd64)
- KDE desktop environment
- Your bundled project copied to: `/opt/myaios/sources`
- Desktop launcher created on first boot: **MyAi OS Operator Panel**
