#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUTDIR="$ROOT/out"
mkdir -p "$OUTDIR"
IMAGE="myaios-livebuild:bookworm"
docker build -t "$IMAGE" "$ROOT/builder"
docker run --rm -t --privileged \
  -v "$ROOT/builder/live-build:/work" \
  -v "$OUTDIR:/out" \
  "$IMAGE" bash -lc '
    set -euo pipefail
    cd /work
    rm -rf .build cache chroot binary || true
    lb clean || true
    lb config \
      --distribution bookworm \
      --architectures amd64 \
      --binary-images iso-hybrid \
      --debian-installer false \
      --archive-areas "main contrib non-free non-free-firmware" \
      --bootappend-live "boot=live components username=user hostname=myaios locales=en_US.UTF-8 keyboard-layouts=us"
    lb build
    ISO=$(ls -1 *.hybrid.iso 2>/dev/null | head -n 1 || true)
    if [[ -z "$ISO" ]]; then ISO=$(ls -1 *.iso 2>/dev/null | head -n 1 || true); fi
    [[ -n "$ISO" ]]
    cp -f "$ISO" /out/MyAiOS-livebookworm-amd64.iso
  '
echo "ISO: $OUTDIR/MyAiOS-livebookworm-amd64.iso"
