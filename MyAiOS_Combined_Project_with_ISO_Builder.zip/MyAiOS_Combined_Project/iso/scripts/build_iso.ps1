$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path (Join-Path $Root "..\..")
Write-Host "[MyAiOS] Requires Docker Desktop + WSL2 running."
wsl bash (Join-Path $ProjectRoot "iso/scripts/build_iso.sh")
