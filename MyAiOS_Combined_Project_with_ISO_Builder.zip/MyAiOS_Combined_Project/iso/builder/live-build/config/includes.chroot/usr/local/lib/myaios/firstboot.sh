#!/usr/bin/env bash
set -euo pipefail
MARKER="/var/lib/myaios/.firstboot_done"
if [[ -f "$MARKER" ]]; then exit 0; fi
mkdir -p /var/lib/myaios /opt/myaios/runtime/logs
DEFAULT_USER="${MYAIOS_USER:-user}"
if ! id "$DEFAULT_USER" >/dev/null 2>&1; then
  useradd -m -s /bin/bash "$DEFAULT_USER"
  echo "$DEFAULT_USER ALL=(ALL) NOPASSWD:ALL" >/etc/sudoers.d/99-myaios-nopasswd
fi
DESK="/home/$DEFAULT_USER/Desktop"
mkdir -p "$DESK"
cat >"$DESK/MyAiOS-Operator.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=MyAi OS Operator Panel
Comment=Launch MyAi OS local operator UI (if present)
Exec=bash -lc '/opt/myaios/runtime/run_operator.sh'
Terminal=true
Icon=utilities-terminal
Categories=Utility;
EOF
chmod +x "$DESK/MyAiOS-Operator.desktop"
chown -R "$DEFAULT_USER:$DEFAULT_USER" "$DESK"
touch "$MARKER"
