# MyAi OS Assets

This folder contains UI assets:

- `agent_hologram.png` - Holographic agent avatar (150x300px)
- `step_icons/` - Status icons for steps
  - `checkmark.png` - Success indicator
  - `spinner.png` - Active/loading indicator
  - `clock.png` - Pending indicator
  - `error.png` - Error indicator

## Creating Assets

### Agent Hologram
Create a transparent PNG with:
- Dimensions: 150x300 pixels
- Blue wireframe/holographic effect
- Transparent background

### Step Icons
Each icon should be:
- 24x24 pixels
- PNG format
- Transparent background
- Use theme colors from `myai_os/ui/theme.py`
