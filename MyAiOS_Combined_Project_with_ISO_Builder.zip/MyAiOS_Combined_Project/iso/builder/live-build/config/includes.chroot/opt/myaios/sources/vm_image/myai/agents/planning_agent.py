"""
planning_agent.py
------------------

This module defines a minimal ``PlanningAgent`` used by MyAi to
translate natural language requests into a list of executable tasks.
The planning agent is responsible for understanding user intent and
breaking it down into discrete actions that can be performed by
specialised agents.  In a production system this would leverage a
large language model or other AI planning technique to generate
dependency graphs, handle complex conditional logic and optimise the
execution order.  Here we provide a simplified implementation that
generates a linear sequence of ``Task`` objects based on key words
found in the user's request.
"""

from __future__ import annotations

import re
from typing import List

from myai.myai_bus import Task


class PlanningAgent:
    """Simple planner that converts user intents into tasks.

    The ``plan`` method examines the request string and emits a list
    of tasks for the bus to run.  Each task specifies the name of the
    action, the target agent and any parameters needed to perform it.
    While real planning would be far more sophisticated, this example
    demonstrates how the API could look and how tasks can be
    orchestrated.
    """

    def plan(self, request: str) -> List[Task]:
        """Generate a list of tasks from a natural language request.

        The current implementation uses simple keyword matching to
        identify a handful of supported verbs.  Unknown requests
        default to a generic acknowledgement via the ``VoiceAgent``.

        Args:
            request: The user's spoken or typed request.

        Returns:
            A list of :class:`Task` instances describing the actions to
            perform in sequence.
        """
        tasks: List[Task] = []
        # Normalise input
        text = request.lower().strip()

        # Example: if the user mentions email and invoices
        if "invoice" in text or "invoices" in text:
            tasks.append(Task(name="speak", params={"message": "Starting invoice processing"}, agent="voice"))
            # open email application
            tasks.append(Task(name="open_application", params={"app": "email"}, agent="system_control"))
            # download attachments
            tasks.append(Task(name="download_attachments", params={}, agent="file"))
            # process invoices
            tasks.append(Task(name="process_documents", params={"type": "invoice"}, agent="document"))
            # summarise results
            tasks.append(Task(name="speak", params={"message": "Invoices processed"}, agent="voice"))
        # Simple file download example
        elif re.search(r"download.*report", text):
            tasks.append(Task(name="speak", params={"message": "Downloading report"}, agent="voice"))
            tasks.append(Task(name="open_application", params={"app": "browser"}, agent="system_control"))
            tasks.append(Task(name="navigate", params={"url": "http://example.com/report"}, agent="browsing"))
            tasks.append(Task(name="download_file", params={"filename": "report.pdf"}, agent="file"))
            tasks.append(Task(name="process_documents", params={"type": "report"}, agent="document"))
            tasks.append(Task(name="speak", params={"message": "Report downloaded and processed"}, agent="voice"))
        else:
            # Default behaviour: echo the request back to the user
            tasks.append(Task(name="speak", params={"message": f"Received request: {request}"}, agent="voice"))
        return tasks

    def handle_task(self, task: Task) -> str:
        """PlanningAgent does not execute tasks itself.

        This method exists only to satisfy the interface expected by
        ``MyAiBus``.  Attempting to dispatch a task directly to the
        planner will raise an error.
        """
        raise ValueError("PlanningAgent is not designed to execute tasks directly")