from myai_os.bus import MyAiBus


class ContextAgent:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        
    async def get_context(self):
        """Get current desktop context"""
        return {
            "active_window": self.get_active_window(),
            "installed_apps": ["Chrome", "Calculator", "Notepad", "Word"],
            "screen_size": "1920x1080"
        }
        
    def get_active_window(self):
        """Get active window title"""
        # Placeholder - implement with win32gui
        return "Browser"
