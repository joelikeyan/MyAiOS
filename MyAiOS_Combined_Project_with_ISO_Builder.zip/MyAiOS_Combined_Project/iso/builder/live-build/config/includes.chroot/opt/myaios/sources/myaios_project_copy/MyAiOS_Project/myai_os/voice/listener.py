import asyncio
import time


class VoiceListener:
    """
    Simplified voice listener - requires pvporcupine and faster-whisper
    Install: pip install pvporcupine faster-whisper pyaudio
    """
    def __init__(self, bus, wake_word="computer"):
        self.bus = bus
        self.wake_word = wake_word
        print(f"Voice listener initialized with wake word: {wake_word}")
        print("Note: Full implementation requires pvporcupine and faster-whisper")
        
    async def start(self):
        """Start listening for wake word"""
        print("Voice listener started")
        print("Full voice implementation requires:")
        print("  - pvporcupine (wake word detection)")
        print("  - faster-whisper (speech recognition)")
        print("  - pyaudio (audio input)")
        
        # Simulation mode - accept text input
        print("\n=== SIMULATION MODE ===")
        print("Voice input not available. Using text simulation.")
        print("Type commands and press Enter.")
        
        while True:
            try:
                command = await asyncio.get_event_loop().run_in_executor(
                    None, input, "Command: "
                )
                if command.strip():
                    print(f"Processing: {command}")
                    await self.bus.process_intent(command)
                    await asyncio.sleep(1)
            except Exception as e:
                print(f"Error: {e}")
                await asyncio.sleep(1)
