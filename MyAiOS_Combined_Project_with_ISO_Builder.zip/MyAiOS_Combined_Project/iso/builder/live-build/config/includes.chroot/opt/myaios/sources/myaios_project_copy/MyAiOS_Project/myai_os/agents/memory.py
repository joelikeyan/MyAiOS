from myai_os.bus import MyAiBus, Event, EventType


class MemoryAgent:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        self.short_term = {}
        self.long_term = []
        bus.subscribe(EventType.STEP_COMPLETED, self.remember)
        
    async def remember(self, event: Event):
        """Store completed steps"""
        step = event.payload.get("step")
        if step:
            self.short_term[f"step_{step.order}"] = {
                "action": step.action,
                "timestamp": event.timestamp
            }
            
    async def recall(self, query: str):
        """Retrieve relevant memory"""
        return self.short_term
