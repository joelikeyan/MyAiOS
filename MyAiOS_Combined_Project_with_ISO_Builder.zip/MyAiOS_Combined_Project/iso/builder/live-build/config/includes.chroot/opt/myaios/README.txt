MyAi OS bundled sources in /opt/myaios/sources
