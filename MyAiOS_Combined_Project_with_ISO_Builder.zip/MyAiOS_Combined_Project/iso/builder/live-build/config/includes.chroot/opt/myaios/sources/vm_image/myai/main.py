"""
main.py
--------

Entry point for a simple MyAi demonstration.  This script wires
together the bus, agents and UI stubs created in this package and
executes a sample request.  It is intended as a testing harness
rather than a production runtime.  Run it with ``python -m myai.main``
to see the system in action.
"""

from __future__ import annotations

import logging

from myai import (
    MyAiBus,
    VoiceAgent,
    PlanningAgent,
    VisionAgent,
    BrowsingAgent,
    DocumentAgent,
    SystemControlAgent,
    FileAgent,
    ValidationAgent,
    DesktopShell,
    OperatorPanel,
)


def main() -> None:
    # Configure logging to display agent output on the console
    logging.basicConfig(level=logging.INFO)

    # Instantiate agents
    voice_agent = VoiceAgent()
    planning_agent = PlanningAgent()
    vision_agent = VisionAgent()
    browsing_agent = BrowsingAgent()
    document_agent = DocumentAgent()
    system_agent = SystemControlAgent()
    file_agent = FileAgent()
    validation_agent = ValidationAgent()

    # Register agents with the bus.  The keys must match Task.agent
    agents = {
        "voice": voice_agent,
        "planning": planning_agent,
        "vision": vision_agent,
        "browsing": browsing_agent,
        "document": document_agent,
        "system_control": system_agent,
        "file": file_agent,
        "validation": validation_agent,
    }
    bus = MyAiBus(agents)

    # Create UI components
    shell = DesktopShell()
    panel = OperatorPanel()

    # A simple user request to test the system
    request = "Download the quarterly performance report and save it to the Reports folder"

    # Use the planning agent to create tasks and populate the operator panel
    tasks = planning_agent.plan(request)
    panel.update_live(tasks)

    # Submit and run tasks
    bus.submit_tasks(tasks)
    bus.run()

    # Record completed tasks in the TRACE tab and collect any file references
    for task in bus.get_trace():
        panel.record_trace(task)
        if task.name in {"download_file", "download_attachments"} and task.result:
            path = task.result.get("path") or ""
            if path:
                panel.add_file_reference(path)

    # Show final operator panel state
    state = panel.get_state()
    print("=== Operator Panel State ===")
    print(state)


if __name__ == "__main__":
    main()