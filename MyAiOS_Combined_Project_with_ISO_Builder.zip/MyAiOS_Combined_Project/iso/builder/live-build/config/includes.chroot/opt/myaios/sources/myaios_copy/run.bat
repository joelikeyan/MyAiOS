@echo off
echo Starting MyAi OS...
call myai_env\Scripts\activate.bat
python -m myai_os.main
pause
