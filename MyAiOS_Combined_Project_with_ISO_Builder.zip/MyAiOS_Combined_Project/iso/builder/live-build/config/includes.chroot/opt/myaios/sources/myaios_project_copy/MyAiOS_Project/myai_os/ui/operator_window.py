import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
from myai_os.bus import EventType


class OperatorWindow:
    def __init__(self, bus):
        self.bus = bus
        self.root = tk.Tk()
        self.setup_window()
        self.create_widgets()
        
        # Subscribe to bus events
        bus.subscribe(EventType.STEP_EXECUTING, self.update_step)
        bus.subscribe(EventType.STEP_COMPLETED, self.mark_complete)
        
    def setup_window(self):
        self.root.title("MyAi Operator")
        self.root.geometry("400x700")
        self.root.configure(bg="#1a2332")
        
        # Always on top, draggable
        self.root.attributes('-topmost', True)
        self.root.overrideredirect(False)
        
        # Transparency
        self.root.attributes('-alpha', 0.95)
        
    def create_widgets(self):
        # Header
        header = tk.Frame(self.root, bg="#0d1621", height=60)
        header.pack(fill=tk.X)
        
        icon_label = tk.Label(header, text="🎤", bg="#0d1621", 
                             fg="white", font=("Segoe UI", 20))
        icon_label.pack(side=tk.LEFT, padx=10)
        
        title_label = tk.Label(header, text="MyAi Operator", 
                              bg="#0d1621", fg="white", 
                              font=("Segoe UI", 14, "bold"))
        title_label.pack(side=tk.LEFT)
        
        # Mode toggles
        mode_frame = tk.Frame(self.root, bg="#1a2332", height=40)
        mode_frame.pack(fill=tk.X, pady=5)
        
        self.base_btn = tk.Button(mode_frame, text="◉ Base", 
                                  bg="#2a3f5f", fg="white",
                                  relief=tk.FLAT, padx=15, pady=5)
        self.base_btn.pack(side=tk.LEFT, padx=5)
        
        self.ai_btn = tk.Button(mode_frame, text="AI ⚡", 
                               bg="#1a2332", fg="#6b8cae",
                               relief=tk.FLAT, padx=15, pady=5)
        self.ai_btn.pack(side=tk.LEFT)
        
        # Task description
        self.task_frame = tk.Frame(self.root, bg="#0d1621", height=80)
        self.task_frame.pack(fill=tk.X, pady=10)
        
        self.task_label = tk.Label(self.task_frame, 
                                   text="Waiting for command...",
                                   bg="#0d1621", fg="#9db4d0",
                                   font=("Segoe UI", 11),
                                   wraplength=350, justify=tk.LEFT)
        self.task_label.pack(padx=15, pady=10)
        
        mic_icon = tk.Label(self.task_frame, text="🎤", 
                           bg="#0d1621", fg="#4a9eff")
        mic_icon.place(relx=0.95, rely=0.5, anchor=tk.E)
        
        # Control buttons
        control_frame = tk.Frame(self.root, bg="#1a2332", height=50)
        control_frame.pack(fill=tk.X, pady=5)
        
        self.pause_btn = self.create_control_btn(control_frame, "⏸", 0)
        self.stop_btn = self.create_control_btn(control_frame, "⏹", 1)
        self.stop_label_btn = self.create_control_btn(control_frame, "📋 Stop", 2)
        self.undo_btn = self.create_control_btn(control_frame, "📷 Undo", 3)
        
        # Tab bar
        tab_frame = tk.Frame(self.root, bg="#0d1621", height=35)
        tab_frame.pack(fill=tk.X)
        
        self.live_tab = self.create_tab(tab_frame, "LIVE", True)
        self.trace_tab = self.create_tab(tab_frame, "TRACE", False)
        self.files_tab = self.create_tab(tab_frame, "FILES", False)
        
        # Step list
        self.step_canvas = tk.Canvas(self.root, bg="#1a2332", 
                                     height=300, highlightthickness=0)
        self.step_canvas.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.step_frame = tk.Frame(self.step_canvas, bg="#1a2332")
        self.step_canvas.create_window((0, 0), window=self.step_frame, anchor=tk.NW)
        
        self.steps = []
        
        # Screenshot previews
        preview_frame = tk.Frame(self.root, bg="#1a2332", height=100)
        preview_frame.pack(fill=tk.X, pady=10)
        
        self.previews = []
        for i in range(3):
            preview = tk.Label(preview_frame, bg="#0d1621", width=120, height=80)
            preview.pack(side=tk.LEFT, padx=5)
            self.previews.append(preview)
        
        # Bottom tabs
        bottom_tab_frame = tk.Frame(self.root, bg="#0d1621", height=35)
        bottom_tab_frame.pack(fill=tk.X)
        
        for tab_name in ["LIVE", "TRACE", "FILES", "SETTINGS"]:
            self.create_tab(bottom_tab_frame, tab_name, tab_name == "LIVE")
        
    def create_control_btn(self, parent, text, index):
        btn = tk.Button(parent, text=text, bg="#2a3f5f", 
                       fg="white", relief=tk.FLAT, 
                       padx=12, pady=8, font=("Segoe UI", 10))
        btn.pack(side=tk.LEFT, padx=3)
        return btn
        
    def create_tab(self, parent, text, active):
        bg_color = "#2a5a8f" if active else "#1a2332"
        fg_color = "white" if active else "#6b8cae"
        
        tab = tk.Label(parent, text=text, bg=bg_color, fg=fg_color,
                      font=("Segoe UI", 9, "bold"), padx=20, pady=8)
        tab.pack(side=tk.LEFT)
        return tab
        
    def add_step(self, text, status="pending"):
        icons = {
            "complete": "✓",
            "active": "⟳",
            "pending": "◷",
            "failed": "✗"
        }
        
        colors = {
            "complete": "#4ade80",
            "active": "#60a5fa",
            "pending": "#6b8cae",
            "failed": "#ef4444"
        }
        
        step_frame = tk.Frame(self.step_frame, bg="#1a2332")
        step_frame.pack(fill=tk.X, pady=3)
        
        icon = tk.Label(step_frame, text=f"{icons[status]} •", 
                       bg="#1a2332", fg=colors[status],
                       font=("Segoe UI", 11))
        icon.pack(side=tk.LEFT, padx=5)
        
        label = tk.Label(step_frame, text=text, bg="#1a2332", 
                        fg=colors[status], font=("Segoe UI", 10),
                        anchor=tk.W)
        label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        activity = tk.Label(step_frame, text="•" if status == "active" else "", 
                           bg="#1a2332", fg=colors[status],
                           font=("Segoe UI", 14))
        activity.pack(side=tk.RIGHT, padx=5)
        
        self.steps.append({
            "frame": step_frame,
            "icon": icon,
            "label": label,
            "activity": activity,
            "status": status
        })
        
    def update_step(self, event):
        step_text = event.payload["step"].action
        self.add_step(step_text, "active")
        self.task_label.config(text=f"Executing: {step_text}")
        
    def mark_complete(self, event):
        if self.steps:
            last_step = self.steps[-1]
            last_step["icon"].config(text="✓ •", fg="#4ade80")
            last_step["label"].config(fg="#4ade80")
            last_step["activity"].config(text="")
            last_step["status"] = "complete"
            
    def run(self):
        self.root.mainloop()
