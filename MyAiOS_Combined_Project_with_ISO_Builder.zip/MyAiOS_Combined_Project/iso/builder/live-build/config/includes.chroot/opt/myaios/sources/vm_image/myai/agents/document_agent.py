"""
document_agent.py
------------------

The ``DocumentAgent`` extracts and processes information from files.
In a complete system this might parse PDFs, spreadsheets or text
documents using libraries such as pdfplumber, pandas or PyPDF2, and
produce structured data for downstream consumption.  Here we
illustrate a very simple version that echoes the file type and
returns dummy metadata.
"""

from __future__ import annotations

from typing import Dict, Any

from myai.myai_bus import Task


class DocumentAgent:
    """Stub agent that processes documents."""

    def handle_task(self, task: Task) -> Dict[str, Any]:
        """Process a document based on its type.

        Supported task names:
            - ``process_documents`` with ``type`` param specifying
              'invoice', 'report', etc.

        Args:
            task: Task describing the document processing job.

        Returns:
            Dictionary with dummy summary statistics.
        """
        if task.name == "process_documents":
            doc_type = task.params.get("type", "unknown")
            # In reality we would open files and extract data here.
            return {"processed": True, "type": doc_type, "count": 1}
        raise ValueError(f"DocumentAgent cannot handle task '{task.name}'")