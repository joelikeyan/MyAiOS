# MyAi OS

Voice-first, agent-orchestrated operating system that executes real desktop actions.

## Features

- 🎤 Voice command interface (wake word: "computer")
- 🤖 Multi-agent orchestration (planner, executor, verifier)
- 👁️ Visual verification using Claude Vision
- 🖥️ Real desktop automation (mouse, keyboard, apps)
- ✅ Step-by-step execution tracking
- 🔄 Interruptible and resumable workflows

## Installation

```bash
# Create virtual environment
python -m venv myai_env

# Activate (Windows)
myai_env\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set API key
set ANTHROPIC_API_KEY=your-key-here
```

## Usage

### With UI (Recommended)

```bash
python -m myai_os.main_with_ui
```

### Console Mode

```bash
python -m myai_os.main
```

## Example Commands


- "Open calculator"
- "Create a new text file and save it as notes.txt"
- "Take a screenshot"
- "Open Chrome and navigate to Google"

## Architecture

```
User Voice Input
       ↓
  MyAi Bus (Event Router)
       ↓
  ┌────┴────┬─────────┬──────────┐
  ↓         ↓         ↓          ↓
Planner  Executor  Verifier  Memory
  ↓         ↓         ↓
Desktop Automation Layer
```

## Configuration

Edit `myai_os/ui/theme.py` to customize colors and appearance.

## Requirements

- Python 3.8+
- Windows (primary), macOS/Linux (experimental)
- Anthropic API key

## Optional Voice Features

For full voice support, install:
```bash
pip install pvporcupine faster-whisper pyaudio
```

## License

MIT License - See LICENSE file
