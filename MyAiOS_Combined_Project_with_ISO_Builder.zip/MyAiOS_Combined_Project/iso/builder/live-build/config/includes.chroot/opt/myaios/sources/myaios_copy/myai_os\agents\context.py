"""
Context Agent - Understands current screen and app state
"""

import asyncio
from typing import Dict, List, Any

try:
    import pyautogui
except ImportError:
    pyautogui = None

try:
    import win32gui
    import win32process
    import psutil
except ImportError:
    print("[WARNING] win32gui/psutil not installed for Windows support")
    win32gui = None

from myai_os.bus import MyAiBus


class ContextAgent:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        self.update_interval = 2  # seconds
        
        # Start background context updating
        asyncio.create_task(self.update_loop())
        
    async def update_loop(self):
        """Continuously update context"""
        while True:
            try:
                context = await self.get_context()
                self.bus.set_state("context", context)
            except Exception as e:
                print(f"[CONTEXT] Update error: {e}")
            
            await asyncio.sleep(self.update_interval)
    
    async def get_context(self) -> Dict[str, Any]:
        """Get current desktop context"""
        context = {
            "timestamp": asyncio.get_event_loop().time(),
            "active_window": self.get_active_window(),
            "screen_size": self.get_screen_size(),
            "cursor_position": self.get_cursor_position(),
            "running_apps": self.get_running_apps()
        }
        
        return context
    
    def get_active_window(self) -> str:
        """Get currently focused window"""
        if not win32gui:
            return "Unknown"
        
        try:
            hwnd = win32gui.GetForegroundWindow()
            title = win32gui.GetWindowText(hwnd)
            return title if title else "Unknown"
        except:
            return "Unknown"
    
    def get_screen_size(self) -> str:
        """Get screen resolution"""
        if not pyautogui:
            return "1920x1080"
        
        try:
            size = pyautogui.size()
            return f"{size.width}x{size.height}"
        except:
            return "1920x1080"
    
    def get_cursor_position(self) -> Dict[str, int]:
        """Get mouse cursor position"""
        if not pyautogui:
            return {"x": 0, "y": 0}
        
        try:
            pos = pyautogui.position()
            return {"x": pos.x, "y": pos.y}
        except:
            return {"x": 0, "y": 0}
    
    def get_running_apps(self) -> List[str]:
        """Get list of running applications"""
        if not win32gui:
            return []
        
        try:
            apps = []
            
            def enum_callback(hwnd, apps):
                if win32gui.IsWindowVisible(hwnd):
                    title = win32gui.GetWindowText(hwnd)
                    if title:
                        apps.append(title)
            
            win32gui.EnumWindows(enum_callback, apps)
            return apps[:10]  # Limit to 10
        except:
            return []
