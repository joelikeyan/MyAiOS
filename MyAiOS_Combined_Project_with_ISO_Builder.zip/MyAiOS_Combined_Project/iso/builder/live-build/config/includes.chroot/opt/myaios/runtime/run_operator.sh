#!/usr/bin/env bash
set -euo pipefail
cd /opt/myaios
LOG="/opt/myaios/runtime/logs/operator.log"
mkdir -p "$(dirname "$LOG")"
echo "[MyAiOS] Starting operator (best-effort)..." | tee -a "$LOG"
CANDIDATES=(
  "/opt/myaios/sources/myaios_project_copy"
  "/opt/myaios/sources/myaios_copy"
  "/opt/myaios/sources/antigravity_full"
)
for d in "${CANDIDATES[@]}"; do
  if [[ -d "$d" ]]; then
    if [[ -f "$d/package.json" ]]; then
      echo "[MyAiOS] Found Node project: $d" | tee -a "$LOG"
      cd "$d"
      if [[ ! -d node_modules ]]; then npm install 2>&1 | tee -a "$LOG"; fi
      if [[ -f package.json ]] && command -v npm >/dev/null 2>&1; then
        npm run dev 2>&1 | tee -a "$LOG" && exit 0
        npm start 2>&1 | tee -a "$LOG" && exit 0
      fi
    fi
    if [[ -f "$d/app.py" ]]; then python3 "$d/app.py" 2>&1 | tee -a "$LOG"; exit 0; fi
    if [[ -f "$d/main.py" ]]; then python3 "$d/main.py" 2>&1 | tee -a "$LOG"; exit 0; fi
  fi
done
echo "[MyAiOS] No runnable operator entrypoint detected in bundled sources." | tee -a "$LOG"
