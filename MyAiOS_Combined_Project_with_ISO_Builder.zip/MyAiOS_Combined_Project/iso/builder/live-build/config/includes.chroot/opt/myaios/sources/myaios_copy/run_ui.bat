@echo off
echo Starting MyAi OS with UI...
call myai_env\Scripts\activate.bat
python -m myai_os.main_with_ui
pause
