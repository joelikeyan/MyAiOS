"""
operator_panel.py
-----------------

This module provides a skeleton ``OperatorPanel`` class that
encapsulates the right‑hand panel described in the MyAi design.  The
panel displays a live narration of the system's activities, a trace
history of all executed tasks, a list of files touched during
execution and controls for adjusting settings.  In a complete
implementation this would be rendered with a GUI framework and
updated in real time as the bus progresses through tasks.  The stub
below maintains simple lists and prints them on demand.
"""

from __future__ import annotations

from typing import List, Tuple, Dict

from myai.myai_bus import Task


class OperatorPanel:
    """Simplified representation of the MyAi operator panel."""

    def __init__(self) -> None:
        # Live tab shows current action and pending steps
        self.live_action: str = ""
        self.live_steps: List[Tuple[str, str]] = []  # (status, description)
        # Trace tab records completed tasks
        self.trace: List[str] = []
        # Files tab collects file references
        self.files: List[str] = []
        # Settings stored as key/value pairs
        self.settings: Dict[str, str] = {
            "narration": "on",
            "privacy": "standard",
        }

    def update_live(self, tasks: List[Task]) -> None:
        """Refresh the LIVE tab with the current plan.

        Args:
            tasks: The list of tasks currently queued for execution.
        """
        self.live_steps = []
        for task in tasks:
            status_symbol = {
                "pending": "\u2022",  # bullet
                "running": "\u25CF",  # black circle
                "success": "\u2714",  # check mark
                "failed": "\u2718",  # cross
            }.get(task.status, "\u2022")
            self.live_steps.append((status_symbol, task.name))

    def record_trace(self, task: Task) -> None:
        """Append a completed task to the TRACE log."""
        status = "success" if task.status == "success" else "failed"
        self.trace.append(f"{status}: {task.name}")

    def add_file_reference(self, path: str) -> None:
        """Add a file path to the FILES tab."""
        self.files.append(path)

    def get_state(self) -> Dict[str, object]:
        """Return a snapshot of the panel state for debugging or display."""
        return {
            "live": {
                "action": self.live_action,
                "steps": self.live_steps,
            },
            "trace": self.trace,
            "files": self.files,
            "settings": self.settings,
        }