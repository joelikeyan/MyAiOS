"""
Enhanced Executor with Visual Feedback
"""

import asyncio
from myai_os.agents.executor import ExecutorAgent

try:
    import pyautogui
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False


class VisualExecutor(ExecutorAgent):
    def __init__(self, bus, overlay=None):
        super().__init__(bus)
        self.overlay = overlay
        
    async def execute_step(self, step):
        """Execute with visual feedback"""
        if self.overlay:
            # Show action tooltip
            if PYAUTOGUI_AVAILABLE:
                x, y = pyautogui.position()
                self.overlay.show_action_tooltip(step.action, x, y)
            
            # Highlight target for click actions
            if "click" in step.action and PYAUTOGUI_AVAILABLE:
                target_x = step.parameters.get("x")
                target_y = step.parameters.get("y")
                if target_x and target_y:
                    self.overlay.highlight_element(target_x, target_y, 100, 40)
                    await asyncio.sleep(0.5)
                    
        result = await super().execute_step(step)
        return result
