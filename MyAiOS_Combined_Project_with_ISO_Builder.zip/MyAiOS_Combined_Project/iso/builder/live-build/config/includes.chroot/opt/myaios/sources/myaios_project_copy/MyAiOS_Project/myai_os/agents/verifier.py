import anthropic
import base64
import time
from io import BytesIO
from PIL import Image
from myai_os.bus import MyAiBus, Event, EventType
from myai_os.agents.planner import Step


class VerifierAgent:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        self.client = anthropic.Anthropic()
        bus.subscribe(EventType.STEP_COMPLETED, self.verify_step)
        
    async def verify_step(self, event: Event):
        step = event.payload["step"]
        result = event.payload["result"]
        
        verified = await self.verify(step, result)
        
        event_type = (EventType.VERIFICATION_PASSED if verified 
                     else EventType.VERIFICATION_FAILED)
        
        await self.bus.publish(Event(
            type=event_type,
            payload={"step": step, "verified": verified},
            timestamp=time.time(),
            source="verifier"
        ))
        
    async def verify(self, step: Step, result: dict) -> bool:
        verification = step.verification
        
        # Visual verification using Claude
        if "screenshot_after" in result:
            return await self.verify_visual(verification, result["screenshot_after"])
            
        return False
        
    async def verify_visual(self, expected: str, screenshot: Image.Image) -> bool:
        """Use Claude vision to verify screenshot matches expectation"""
        buffer = BytesIO()
        screenshot.save(buffer, format="PNG")
        image_data = base64.b64encode(buffer.getvalue()).decode()
        
        response = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=100,
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/png",
                            "data": image_data
                        }
                    },
                    {
                        "type": "text",
                        "text": f"Does this screenshot show: {expected}\nRespond only: YES or NO"
                    }
                ]
            }]
        )
        
        return "YES" in response.content[0].text.upper()
