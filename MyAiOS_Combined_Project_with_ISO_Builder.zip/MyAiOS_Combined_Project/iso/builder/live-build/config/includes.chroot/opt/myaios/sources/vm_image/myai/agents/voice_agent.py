"""
voice_agent.py
----------------

This module defines the ``VoiceAgent`` class used by MyAi to capture
spoken input from the user and to provide basic speech feedback.  In a
full implementation this agent would continuously listen for audio,
transcribe the speech using a speech‑to‑text engine and emit the
resulting text back into the system.  The agent could also synthesise
speech to provide audible confirmations.

For the purposes of this proof‑of‑concept the ``VoiceAgent`` simply
stores a queue of preconfigured utterances and returns them on demand.
It also logs any prompts to the console to demonstrate how narration
could be implemented.
"""

from __future__ import annotations

import logging
from typing import List, Optional

from .planning_agent import Task  # type: ignore  # circular import safe at runtime


class VoiceAgent:
    """Simple voice agent stub.

    This agent simulates continuous listening by popping lines of text
    from an internal buffer.  In a real deployment this class would
    integrate with a microphone and speech recognition engine to
    generate transcripts in real time.  The ``handle_task`` method can
    also be used by the bus to synthesise speech when the system needs
    to respond verbally.
    """

    def __init__(self, script: Optional[List[str]] = None) -> None:
        """
        Initialise the voice agent.

        Args:
            script: Optional list of strings to serve as preloaded
                transcripts.  Each call to :meth:`listen` will return
                the next line of the script.  This is useful for
                deterministic testing.
        """
        self.script = script or []
        self.logger = logging.getLogger(self.__class__.__name__)

    def listen(self) -> Optional[str]:
        """Simulate listening to the user and returning a transcript.

        Returns ``None`` when no scripted utterances are left.
        """
        if self.script:
            utterance = self.script.pop(0)
            self.logger.debug(f"VoiceAgent heard: {utterance}")
            return utterance
        # In a real implementation, blocking listen on microphone here
        return None

    def speak(self, message: str) -> None:
        """Simulate speech synthesis by logging a message.

        Args:
            message: The text to speak.
        """
        self.logger.info(f"MyAi says: {message}")

    def handle_task(self, task: Task) -> str:
        """Handle a task dispatched from the MyAiBus.

        The voice agent responds to two kinds of tasks:

        - ``listen``: returns the next utterance from the user.
        - ``speak``: logs the message as if speaking it aloud.

        Args:
            task: A Task instance describing the action.

        Returns:
            A string result or acknowledgement.

        Raises:
            ValueError: If an unsupported task name is provided.
        """
        if task.name == "listen":
            utterance = self.listen()
            return utterance or ""
        elif task.name == "speak":
            message = task.params.get("message", "")
            self.speak(message)
            return "spoken"
        else:
            raise ValueError(f"VoiceAgent cannot handle task '{task.name}'")