param (
    [ValidateSet("Install", "Uninstall")]
    [string]$Action = "Install"
)

$rootKey = "HKCR\*\shell\JoeTools"
$subKey = "$rootKey\shell"
$iconPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"

$commands = @{
    OpenTerminal = @{
        Label = "🖥️ Open in Terminal"
        Icon  = "wt.exe"
        Cmd   = 'wt.exe -d "%~dp1"'
    }
    EditVSCode = @{
        Label = "📝 Edit with VS Code"
        Icon  = "code.exe"
        Cmd   = 'code "%1"'
    }
    RunAdminPS = @{
        Label = "⚡ Run with Admin PowerShell"
        Icon  = "powershell.exe"
        Cmd   = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process ''%1'' -Verb RunAs"'
    }
    OpenNormal = @{
        Label = "📂 Open"
        Icon  = "explorer.exe"
        Cmd   = 'explorer.exe "%1"'
    }
    RunAsAdmin = @{
        Label = "🔼 Run as Administrator"
        Icon  = "powershell.exe"
        Cmd   = 'Start-Process "%1" -Verb RunAs'
    }
}

function Install-JoeTools {
    New-Item -Path $rootKey -Force | Out-Null
    Set-ItemProperty -Path $rootKey -Name "(Default)" -Value "Joe Tools"
    Set-ItemProperty -Path $rootKey -Name "Icon" -Value $iconPath

    foreach ($name in $commands.Keys) {
        $cmdInfo = $commands[$name]
        $cmdKey = "$subKey\$name"
        $cmdCmdKey = "$cmdKey\command"

        New-Item -Path $cmdKey -Force | Out-Null
        Set-ItemProperty -Path $cmdKey -Name "(Default)" -Value $cmdInfo.Label
        Set-ItemProperty -Path $cmdKey -Name "Icon" -Value $cmdInfo.Icon

        New-Item -Path $cmdCmdKey -Force | Out-Null
        Set-ItemProperty -Path $cmdCmdKey -Name "(Default)" -Value $cmdInfo.Cmd
    }

    Write-Host "Joe Tools context menu suite installed."
}

function Uninstall-JoeTools {
    Remove-Item -Path $rootKey -Recurse -Force
    Write-Host "Joe Tools context menu suite removed."
}

if ($Action -eq "Install") { Install-JoeTools }
elseif ($Action -eq "Uninstall") { Uninstall-JoeTools }