Trigger wake word; issue command; pause; resume; store timings/logs in artifacts/.
