"""
Memory Agent - Tracks context and user patterns
"""

import asyncio
import json
from typing import Dict, List, Any
from pathlib import Path
from datetime import datetime

from myai_os.bus import MyAiBus, Event, EventType


class MemoryAgent:
    def __init__(self, bus: MyAiBus, storage_path: str = "memory.json"):
        self.bus = bus
        self.storage_path = Path(storage_path)
        self.short_term: Dict[str, Any] = {}
        self.long_term: List[Dict[str, Any]] = []
        
        # Subscribe to all events
        for event_type in EventType:
            bus.subscribe(event_type, self.remember)
        
        # Load existing memory
        self.load_memory()
        
    def load_memory(self):
        """Load long-term memory from disk"""
        if self.storage_path.exists():
            try:
                with open(self.storage_path, 'r') as f:
                    data = json.load(f)
                    self.long_term = data.get("long_term", [])
                    print(f"[MEMORY] Loaded {len(self.long_term)} memories")
            except Exception as e:
                print(f"[MEMORY] Load error: {e}")
    
    def save_memory(self):
        """Save long-term memory to disk"""
        try:
            with open(self.storage_path, 'w') as f:
                json.dump({
                    "long_term": self.long_term[-100:],  # Keep last 100
                    "updated": datetime.now().isoformat()
                }, f, indent=2)
        except Exception as e:
            print(f"[MEMORY] Save error: {e}")
    
    async def remember(self, event: Event):
        """Store event in memory"""
        memory_item = {
            "type": event.type.value,
            "timestamp": event.timestamp,
            "source": event.source,
            "payload": str(event.payload)[:500]  # Truncate
        }
        
        # Short-term (current session)
        self.short_term[event.id] = memory_item
        
        # Long-term (important events only)
        if event.type in [EventType.TASK_COMPLETED, EventType.TASK_FAILED]:
            self.long_term.append(memory_item)
            self.save_memory()
    
    async def recall(self, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Retrieve relevant memories"""
        # Simple keyword search
        query_lower = query.lower()
        results = []
        
        for memory in reversed(self.long_term):
            if query_lower in memory["payload"].lower():
                results.append(memory)
                if len(results) >= limit:
                    break
        
        return results
    
    def get_recent(self, limit: int = 5) -> List[Dict[str, Any]]:
        """Get recent memories"""
        return list(self.short_term.values())[-limit:]
