"""
Example: Budget Tracker Creation

Demonstrates how MyAi OS can create and manage a budget spreadsheet.
"""

# This would be triggered by voice command:
# "Computer, create a budget tracker for January 2026"

EXAMPLE_PLAN = [
    {
        "order": 1,
        "action": "open_application",
        "parameters": {"app_name": "Excel"},
        "verification": "Window title contains 'Excel'"
    },
    {
        "order": 2,
        "action": "type_text",
        "parameters": {"text": "Date\tItem\tCategory\tAmount\tBalance"},
        "verification": "Headers visible in first row"
    },
    {
        "order": 3,
        "action": "press_keys",
        "parameters": {"keys": ["enter"]},
        "verification": "Cursor moved to next row"
    },
    {
        "order": 4,
        "action": "save_file",
        "parameters": {"path": "C:\\Users\\Budget_Jan2026.xlsx"},
        "verification": "File exists in Documents"
    }
]

if __name__ == "__main__":
    print("Budget Tracker Example Plan:")
    for step in EXAMPLE_PLAN:
        print(f"{step['order']}. {step['action']}: {step['parameters']}")
