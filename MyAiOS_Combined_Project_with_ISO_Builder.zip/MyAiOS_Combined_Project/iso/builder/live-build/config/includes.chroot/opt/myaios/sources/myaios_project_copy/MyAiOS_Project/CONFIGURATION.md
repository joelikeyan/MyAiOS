# MyAi OS Configuration Guide

## Quick Start

### 1. Set API Key

**Windows:**
```cmd
set ANTHROPIC_API_KEY=sk-ant-your-key-here
```

**Or create `.env` file:**
```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

### 2. Run Setup
```cmd
setup.bat
```

### 3. Start MyAi OS
```cmd
run.bat
```

## Customization

### Change Wake Word

Edit `myai_os/main_with_ui.py`:
```python
listener = VoiceListener(bus, wake_word="jarvis")
```

### Modify UI Theme

Edit `myai_os/ui/theme.py`:
```python
THEME = {
    "colors": {
        "bg_primary": "#your_color",
        ...
    }
}
```

### Add Custom Actions

Edit `myai_os/agents/executor.py` and add new methods:
```python
async def my_custom_action(self, param: str) -> bool:
    # Your automation code
    return True
```

## Troubleshooting

### API Key Issues

- Verify key is set: `echo %ANTHROPIC_API_KEY%`
- Check key format starts with `sk-ant-`

### pyautogui Failsafe
If mouse goes to corner and stops automation:
```python
pyautogui.FAILSAFE = False  # In executor.py
```

### UI Not Showing
Check tkinter is installed:
```cmd
python -c "import tkinter"
```

### Voice Not Working
Install optional dependencies:
```cmd
pip install pvporcupine faster-whisper pyaudio
```

## Memory Optimization

For low-memory systems, reduce verification screenshots:
```python
# In verifier.py
screenshot.thumbnail((640, 480))  # Reduce size
```
