"""
Example: Test MyAi OS Components

Simple test to verify all components are working.
"""

import asyncio
from myai_os.bus import MyAiBus, Event, EventType


async def test_bus():
    """Test event bus"""
    print("Testing MyAi Bus...")
    
    bus = MyAiBus()
    received = []
    
    def handler(event):
        received.append(event)
        print(f"  ✓ Received: {event.type}")
    
    bus.subscribe(EventType.INTENT_RECEIVED, handler)
    
    await bus.process_intent("test command")
    
    assert len(received) == 1
    print("✓ Bus working\n")


async def test_agents():
    """Test agent initialization"""
    print("Testing Agents...")
    
    from myai_os.agents.planner import PlannerAgent
    from myai_os.agents.executor import ExecutorAgent
    from myai_os.agents.memory import MemoryAgent
    
    bus = MyAiBus()
    
    planner = PlannerAgent(bus)
    print("  ✓ Planner initialized")
    
    executor = ExecutorAgent(bus)
    print("  ✓ Executor initialized")
    
    memory = MemoryAgent(bus)
    print("  ✓ Memory initialized")
    
    print("✓ All agents working\n")


async def main():
    print("=" * 50)
    print("MyAi OS System Test")
    print("=" * 50)
    print()
    
    await test_bus()
    await test_agents()
    
    print("=" * 50)
    print("All tests passed! ✓")
    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())
