"""
Voice Listener - Wake word detection and speech recognition
"""

import asyncio
import struct
import wave
import tempfile
from pathlib import Path

try:
    import pvporcupine
except ImportError:
    print("[WARNING] pvporcupine not installed. Wake word detection disabled.")
    pvporcupine = None

try:
    import pyaudio
except ImportError:
    print("[WARNING] pyaudio not installed. Voice input disabled.")
    pyaudio = None

try:
    from faster_whisper import WhisperModel
except ImportError:
    print("[WARNING] faster-whisper not installed. Using fallback recognition.")
    WhisperModel = None

from myai_os.bus import MyAiBus


class VoiceListener:
    def __init__(self, bus: MyAiBus, wake_word="computer"):
        self.bus = bus
        self.wake_word = wake_word
        
        # Initialize wake word detector
        if pvporcupine:
            try:
                self.porcupine = pvporcupine.create(keywords=[wake_word])
            except:
                print(f"[VOICE] Could not initialize wake word '{wake_word}'")
                self.porcupine = None
        else:
            self.porcupine = None
        
        # Initialize speech recognition
        if WhisperModel:
            try:
                self.whisper = WhisperModel("base.en", device="cpu", compute_type="int8")
            except:
                print("[VOICE] Whisper model not available")
                self.whisper = None
        else:
            self.whisper = None
        
        # Initialize audio
        if pyaudio:
            self.pa = pyaudio.PyAudio()
        else:
            self.pa = None
        
    async def start(self):
        """Start listening for wake word and commands"""
        if not self.pa or not self.porcupine:
            print("[VOICE] Voice input not available. Entering demo mode...")
            await self.demo_mode()
            return
        
        try:
            stream = self.pa.open(
                rate=self.porcupine.sample_rate,
                channels=1,
                format=pyaudio.paInt16,
                input=True,
                frames_per_buffer=self.porcupine.frame_length
            )
            
            print(f"[VOICE] Listening for wake word: '{self.wake_word}'...")
            
            while True:
                pcm = stream.read(self.porcupine.frame_length)
                pcm = struct.unpack_from("h" * self.porcupine.frame_length, pcm)
                
                keyword_index = self.porcupine.process(pcm)
                
                if keyword_index >= 0:
                    print(f"[VOICE] Wake word detected!")
                    intent = await self.capture_command(stream)
                    if intent:
                        await self.bus.process_intent(intent)
        except Exception as e:
            print(f"[VOICE] Error: {e}")
        finally:
            if stream:
                stream.close()
    
    async def capture_command(self, stream) -> str:
        """Capture and transcribe voice command"""
        print("[VOICE] Listening for command...")
        
        # Record 3 seconds of audio
        frames = []
        for i in range(0, int(self.porcupine.sample_rate / self.porcupine.frame_length * 3)):
            data = stream.read(self.porcupine.frame_length)
            frames.append(data)
        
        # Save to temp file
        temp_path = Path(tempfile.gettempdir()) / "myai_command.wav"
        with wave.open(str(temp_path), 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(self.pa.get_sample_size(pyaudio.paInt16))
            wf.setframerate(self.porcupine.sample_rate)
            wf.writeframes(b''.join(frames))
        
        # Transcribe
        if self.whisper:
            segments, _ = self.whisper.transcribe(str(temp_path))
            command = ' '.join([seg.text for seg in segments])
        else:
            command = "open calculator"  # Fallback
        
        print(f"[VOICE] Command: {command}")
        return command.strip()
    
    async def demo_mode(self):
        """Demo mode with keyboard input"""
        print("\n" + "="*50)
        print("DEMO MODE: Voice input not available")
        print("Type commands directly (or 'quit' to exit)")
        print("="*50 + "\n")
        
        while True:
            try:
                command = await asyncio.to_thread(input, "Enter command: ")
                if command.lower() in ['quit', 'exit', 'q']:
                    break
                if command.strip():
                    await self.bus.process_intent(command)
            except (EOFError, KeyboardInterrupt):
                break
