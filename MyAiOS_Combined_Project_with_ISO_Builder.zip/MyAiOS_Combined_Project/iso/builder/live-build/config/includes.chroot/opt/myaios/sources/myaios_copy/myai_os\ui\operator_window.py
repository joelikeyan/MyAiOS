"""
MyAi Operator Window - Main UI Panel
"""

import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
from threading import Thread
from typing import List, Dict, Any

from myai_os.bus import MyAiBus, Event, EventType
from myai_os.ui.theme import THEME


class OperatorWindow:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        self.root = tk.Tk()
        self.steps: List[Dict] = []
        self.previews: List[tk.Label] = []
        
        self.setup_window()
        self.create_widgets()
        
        # Subscribe to bus events
        bus.subscribe(EventType.STEP_EXECUTING, self.update_step)
        bus.subscribe(EventType.STEP_COMPLETED, self.mark_complete)
        bus.subscribe(EventType.INTENT_RECEIVED, self.update_task)
        
    def setup_window(self):
        """Configure main window"""
        self.root.title("MyAi Operator")
        self.root.geometry("400x750")
        self.root.configure(bg=THEME["colors"]["bg_primary"])
        
        # Always on top
        self.root.attributes('-topmost', True)
        
        # Transparency
        self.root.attributes('-alpha', 0.95)
        
    def create_widgets(self):
        """Build all UI components"""
        # Header
        header = tk.Frame(self.root, bg=THEME["colors"]["bg_secondary"], height=60)
        header.pack(fill=tk.X)
        
        icon_label = tk.Label(header, text="🎤", 
                             bg=THEME["colors"]["bg_secondary"], 
                             fg="white", font=("Segoe UI", 20))
        icon_label.pack(side=tk.LEFT, padx=10)
        
        title_label = tk.Label(header, text="MyAi Operator", 
                              bg=THEME["colors"]["bg_secondary"], 
                              fg="white", 
                              font=THEME["fonts"]["header"])
        title_label.pack(side=tk.LEFT)
        
        # Mode toggles
        mode_frame = tk.Frame(self.root, bg=THEME["colors"]["bg_primary"], height=40)
        mode_frame.pack(fill=tk.X, pady=5)
        
        self.base_btn = tk.Button(mode_frame, text="◉ Base", 
                                  bg=THEME["colors"]["bg_control"], 
                                  fg="white",
                                  relief=tk.FLAT, padx=15, pady=5,
                                  font=THEME["fonts"]["primary"])
        self.base_btn.pack(side=tk.LEFT, padx=5)
        
        self.ai_btn = tk.Button(mode_frame, text="AI ⚡", 
                               bg=THEME["colors"]["bg_primary"], 
                               fg=THEME["colors"]["text_muted"],
                               relief=tk.FLAT, padx=15, pady=5,
                               font=THEME["fonts"]["primary"])
        self.ai_btn.pack(side=tk.LEFT)
        
        # Task description
        self.task_frame = tk.Frame(self.root, bg=THEME["colors"]["bg_secondary"], height=80)
        self.task_frame.pack(fill=tk.X, pady=10)
        
        self.task_label = tk.Label(self.task_frame, 
                                   text="Waiting for command...",
                                   bg=THEME["colors"]["bg_secondary"], 
                                   fg=THEME["colors"]["text_secondary"],
                                   font=THEME["fonts"]["title"],
                                   wraplength=350, justify=tk.LEFT)
        self.task_label.pack(padx=15, pady=10)
        
        mic_icon = tk.Label(self.task_frame, text="🎤", 
                           bg=THEME["colors"]["bg_secondary"], 
                           fg=THEME["colors"]["accent_blue"])
        mic_icon.place(relx=0.95, rely=0.5, anchor=tk.E)
        
        # Control buttons
        control_frame = tk.Frame(self.root, bg=THEME["colors"]["bg_primary"], height=50)
        control_frame.pack(fill=tk.X, pady=5)
        
        self.pause_btn = self.create_control_btn(control_frame, "⏸", self.on_pause)
        self.stop_btn = self.create_control_btn(control_frame, "⏹", self.on_stop)
        self.stop_label_btn = self.create_control_btn(control_frame, "📋 Stop", self.on_stop)
        self.undo_btn = self.create_control_btn(control_frame, "📷 Undo", self.on_undo)
        
        # Tab bar
        tab_frame = tk.Frame(self.root, bg=THEME["colors"]["bg_secondary"], height=35)
        tab_frame.pack(fill=tk.X)
        
        self.live_tab = self.create_tab(tab_frame, "LIVE", True)
        self.trace_tab = self.create_tab(tab_frame, "TRACE", False)
        self.files_tab = self.create_tab(tab_frame, "FILES", False)
        
        # Step list with scrollbar
        step_container = tk.Frame(self.root, bg=THEME["colors"]["bg_primary"])
        step_container.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.step_canvas = tk.Canvas(step_container, 
                                     bg=THEME["colors"]["bg_primary"], 
                                     highlightthickness=0)
        scrollbar = tk.Scrollbar(step_container, orient=tk.VERTICAL, 
                                command=self.step_canvas.yview)
        self.step_canvas.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.step_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        self.step_frame = tk.Frame(self.step_canvas, bg=THEME["colors"]["bg_primary"])
        self.step_canvas.create_window((0, 0), window=self.step_frame, anchor=tk.NW)
        
        # Screenshot previews
        preview_frame = tk.Frame(self.root, bg=THEME["colors"]["bg_primary"], height=100)
        preview_frame.pack(fill=tk.X, pady=10)
        
        for i in range(3):
            preview = tk.Label(preview_frame, 
                              bg=THEME["colors"]["bg_secondary"], 
                              width=15, height=6,
                              text=f"Preview {i+1}",
                              fg=THEME["colors"]["text_muted"])
            preview.pack(side=tk.LEFT, padx=5)
            self.previews.append(preview)
        
        # Bottom tabs
        bottom_tab_frame = tk.Frame(self.root, bg=THEME["colors"]["bg_secondary"], height=35)
        bottom_tab_frame.pack(fill=tk.X)
        
        for tab_name in ["LIVE", "TRACE", "FILES", "SETTINGS"]:
            self.create_tab(bottom_tab_frame, tab_name, tab_name == "LIVE")
    
    def create_control_btn(self, parent, text, command):
        """Create control button"""
        btn = tk.Button(parent, text=text, 
                       bg=THEME["colors"]["bg_control"], 
                       fg="white", relief=tk.FLAT, 
                       padx=12, pady=8, 
                       font=THEME["fonts"]["primary"],
                       command=command)
        btn.pack(side=tk.LEFT, padx=3)
        return btn
        
    def create_tab(self, parent, text, active):
        """Create tab label"""
        bg_color = THEME["colors"]["accent_active"] if active else THEME["colors"]["bg_primary"]
        fg_color = "white" if active else THEME["colors"]["text_muted"]
        
        tab = tk.Label(parent, text=text, bg=bg_color, fg=fg_color,
                      font=THEME["fonts"]["small"], padx=20, pady=8)
        tab.pack(side=tk.LEFT)
        return tab
    
    def add_step(self, text, status="pending"):
        """Add step to live view"""
        icons = {
            "complete": "✓",
            "active": "⟳",
            "pending": "◷",
            "failed": "✗"
        }
        
        colors = {
            "complete": THEME["colors"]["success"],
            "active": THEME["colors"]["accent_blue"],
            "pending": THEME["colors"]["text_muted"],
            "failed": THEME["colors"]["error"]
        }
        
        step_frame = tk.Frame(self.step_frame, bg=THEME["colors"]["bg_primary"])
        step_frame.pack(fill=tk.X, pady=3, padx=10)
        
        icon = tk.Label(step_frame, text=f"{icons[status]} •", 
                       bg=THEME["colors"]["bg_primary"], 
                       fg=colors[status],
                       font=("Segoe UI", 11))
        icon.pack(side=tk.LEFT, padx=5)
        
        label = tk.Label(step_frame, text=text, 
                        bg=THEME["colors"]["bg_primary"], 
                        fg=colors[status], 
                        font=THEME["fonts"]["primary"],
                        anchor=tk.W)
        label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        activity = tk.Label(step_frame, text="•" if status == "active" else "", 
                           bg=THEME["colors"]["bg_primary"], 
                           fg=colors[status],
                           font=("Segoe UI", 14))
        activity.pack(side=tk.RIGHT, padx=5)
        
        self.steps.append({
            "frame": step_frame,
            "icon": icon,
            "label": label,
            "activity": activity,
            "status": status
        })
        
        # Update scroll region
        self.step_frame.update_idletasks()
        self.step_canvas.configure(scrollregion=self.step_canvas.bbox("all"))
    
    def update_step(self, event: Event):
        """Handle step execution start"""
        step = event.payload.get("step")
        if step:
            step_text = step.action if hasattr(step, 'action') else str(step)
            self.add_step(f"• {step_text}", "active")
            self.task_label.config(text=f"Executing: {step_text}")
        
    def mark_complete(self, event: Event):
        """Mark last step as complete"""
        if self.steps:
            last_step = self.steps[-1]
            last_step["icon"].config(text="✓ •", fg=THEME["colors"]["success"])
            last_step["label"].config(fg=THEME["colors"]["success"])
            last_step["activity"].config(text="")
            last_step["status"] = "complete"
    
    def update_task(self, event: Event):
        """Update task description"""
        intent = event.payload.get("intent", "Processing...")
        self.task_label.config(text=intent)
        
        # Clear previous steps
        for step in self.steps:
            step["frame"].destroy()
        self.steps.clear()
        
        # Add initial plan step
        self.add_step("Plan", "complete")
    
    def on_pause(self):
        """Handle pause button"""
        print("[UI] Pause requested")
        
    def on_stop(self):
        """Handle stop button"""
        print("[UI] Stop requested")
        
    def on_undo(self):
        """Handle undo button"""
        print("[UI] Undo requested")
        
    def run(self):
        """Start UI main loop"""
        self.root.mainloop()
