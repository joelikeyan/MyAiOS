"""
MyAi OS - Main Entry Point with UI
"""

import asyncio
from threading import Thread

from myai_os.bus import MyAiBus
from myai_os.agents.planner import PlannerAgent
from myai_os.agents.executor_visual import VisualExecutor
from myai_os.agents.verifier import VerifierAgent
from myai_os.agents.memory import MemoryAgent
from myai_os.agents.context import ContextAgent
from myai_os.ui.operator_window import OperatorWindow
from myai_os.ui.desktop_overlay import DesktopOverlay
from myai_os.ui.folder_badges import FolderBadgeSystem
from myai_os.voice.listener import VoiceListener


def run_ui(window):
    """Run UI in separate thread"""
    window.run()


def print_banner():
    """Print startup banner"""
    print("\n" + "="*60)
    print("  __  __       _    _    ___  ____  ")
    print(" |  \/  |_   _/ \  (_)  / _ \/ ___| ")
    print(" | |\/| | | | / _ \ | | | | | \___ \ ")
    print(" | |  | | |_| / ___ \| | | |_| |___) |")
    print(" |_|  |_|\__, /_/   \_\_|  \___/|____/ ")
    print("         |___/                         ")
    print("\n  AI-Native Operating System v1.0")
    print("="*60 + "\n")


async def main():
    """Main application entry point with UI"""
    print_banner()
    
    # Initialize bus
    bus = MyAiBus()
    print("✓ Initialized event bus")
    
    # Create UI components
    operator_window = OperatorWindow(bus)
    print("✓ Operator window created")
    
    overlay = DesktopOverlay(bus)
    print("✓ Desktop overlay ready")
    
    badges = FolderBadgeSystem()
    print("✓ Badge system ready")
    
    # Initialize agents with UI
    context_agent = ContextAgent(bus)
    print("✓ Context agent ready")
    
    memory_agent = MemoryAgent(bus)
    print("✓ Memory agent ready")
    
    planner = PlannerAgent(bus)
    print("✓ Planner agent ready")
    
    executor = VisualExecutor(bus, overlay)
    print("✓ Visual executor ready")
    
    verifier = VerifierAgent(bus)
    print("✓ Verifier agent ready")
    
    # Show agent avatar
    overlay.show_agent_avatar()
    
    # Run UI in separate thread
    ui_thread = Thread(target=run_ui, args=(operator_window,), daemon=True)
    ui_thread.start()
    print("✓ UI started")
    
    # Start voice listener
    listener = VoiceListener(bus)
    
    print("\n" + "="*60)
    print("MyAi OS with UI is ready!")
    print("Say 'computer' followed by your command")
    print("Or type commands directly if voice is not available")
    print("="*60 + "\n")
    
    await listener.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\nShutting down MyAi OS...")
