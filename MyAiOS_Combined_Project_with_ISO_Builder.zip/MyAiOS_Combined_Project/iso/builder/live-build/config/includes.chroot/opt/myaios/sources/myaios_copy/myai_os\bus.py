"""
MyAi Bus - Event-Driven Orchestration System
Coordinates all agents and manages task flow
"""

import asyncio
import time
from typing import Dict, List, Callable, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class EventType(Enum):
    INTENT_RECEIVED = "intent_received"
    PLAN_CREATED = "plan_created"
    STEP_EXECUTING = "step_executing"
    STEP_COMPLETED = "step_completed"
    VERIFICATION_PASSED = "verification_passed"
    VERIFICATION_FAILED = "verification_failed"
    TASK_COMPLETED = "task_completed"
    TASK_FAILED = "task_failed"
    ERROR = "error"
    CONTEXT_UPDATED = "context_updated"


@dataclass
class Event:
    type: EventType
    payload: Dict[str, Any]
    timestamp: float
    source: str
    id: str = field(default_factory=lambda: str(time.time()))


class MyAiBus:
    def __init__(self):
        self.subscribers: Dict[EventType, List[Callable]] = {}
        self.state: Dict[str, Any] = {}
        self.task_queue = asyncio.Queue()
        self.event_history: List[Event] = []
        self.current_task = None
        
    def subscribe(self, event_type: EventType, handler: Callable):
        """Register a handler for specific event type"""
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        self.subscribers[event_type].append(handler)
        print(f"[BUS] Subscribed {handler.__name__} to {event_type.value}")
        
    async def publish(self, event: Event):
        """Publish event to all subscribers"""
        self.event_history.append(event)
        print(f"[BUS] Publishing {event.type.value} from {event.source}")
        
        if event.type in self.subscribers:
            tasks = [handler(event) for handler in self.subscribers[event.type]]
            await asyncio.gather(*tasks, return_exceptions=True)
            
    async def process_intent(self, intent: str):
        """Entry point for user intents"""
        event = Event(
            type=EventType.INTENT_RECEIVED,
            payload={"intent": intent},
            timestamp=time.time(),
            source="voice_input"
        )
        await self.publish(event)
        
    def set_state(self, key: str, value: Any):
        """Update global state"""
        self.state[key] = value
        
    def get_state(self, key: str, default=None) -> Any:
        """Retrieve state value"""
        return self.state.get(key, default)
        
    async def get_context(self) -> Dict[str, Any]:
        """Get current system context"""
        return self.state.get("context", {})


# Global bus instance
bus = MyAiBus()
