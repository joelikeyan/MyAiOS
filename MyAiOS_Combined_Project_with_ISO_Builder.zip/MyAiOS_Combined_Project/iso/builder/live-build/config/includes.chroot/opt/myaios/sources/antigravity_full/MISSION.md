Build a self-hosted, voice-first, agent-orchestrated OS that runs a real desktop in Docker, supports wake-word voice control, and verifies outcomes with artifacts.
