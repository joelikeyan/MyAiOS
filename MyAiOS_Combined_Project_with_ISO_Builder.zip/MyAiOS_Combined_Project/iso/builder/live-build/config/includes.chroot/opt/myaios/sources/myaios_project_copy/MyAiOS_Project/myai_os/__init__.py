"""
MyAi OS - Voice-First Agent-Orchestrated Operating System
"""

__version__ = "1.0.0"
__author__ = "MyAi OS Team"
