"""
MyAi OS - AI-Native Operating System
Voice-first, agent-orchestrated desktop automation
"""

__version__ = "1.0.0"
__author__ = "MyAi OS Team"
