import anthropic
import json
import time
from typing import List, Dict
from dataclasses import dataclass
from myai_os.bus import MyAiBus, Event, EventType


@dataclass
class Step:
    order: int
    action: str
    parameters: Dict
    verification: str


class PlannerAgent:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        self.client = anthropic.Anthropic()
        bus.subscribe(EventType.INTENT_RECEIVED, self.handle_intent)
        
    async def handle_intent(self, event: Event):
        intent = event.payload["intent"]
        context = await self.bus.get_context()
        
        plan = await self.create_plan(intent, context)
        
        await self.bus.publish(Event(
            type=EventType.PLAN_CREATED,
            payload={"plan": plan},
            timestamp=time.time(),
            source="planner"
        ))
        
    async def create_plan(self, intent: str, context: Dict) -> List[Step]:
        prompt = f"""You are a desktop automation planner.

User intent: {intent}

Current context:
- Active window: {context.get('active_window')}
- Available apps: {context.get('installed_apps')}
- Screen resolution: {context.get('screen_size')}

Create an execution plan as JSON array:
[
  {{
    "order": 1,
    "action": "open_application",
    "parameters": {{"app_name": "Calculator"}},
    "verification": "Window title contains 'Calculator'"
  }}
]

Actions available:
- open_application(app_name)
- click_element(description, x, y)
- type_text(text, field_description)
- press_keys(keys)
- save_file(path)
- wait(seconds)

Output only valid JSON."""

        response = await self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )
        
        plan_json = response.content[0].text
        return self.parse_plan(plan_json)
        
    def parse_plan(self, plan_json: str) -> List[Step]:
        """Parse JSON plan into Step objects"""
        try:
            # Remove markdown code blocks if present
            plan_json = plan_json.replace("```json", "").replace("```", "").strip()
            
            data = json.loads(plan_json)
            steps = []
            for item in data:
                step = Step(
                    order=item["order"],
                    action=item["action"],
                    parameters=item["parameters"],
                    verification=item["verification"]
                )
                steps.append(step)
            return steps
        except Exception as e:
            print(f"Error parsing plan: {e}")
            return []
