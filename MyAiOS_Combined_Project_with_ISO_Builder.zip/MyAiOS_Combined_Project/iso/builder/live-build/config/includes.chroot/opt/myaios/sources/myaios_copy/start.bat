@echo off
echo ========================================
echo MyAi OS - Quick Start
echo ========================================
echo.

REM Activate virtual environment
call myai_env\Scripts\activate.bat

REM Run MyAi OS
python -m myai_os.main

pause
