@echo off
echo ================================
echo MyAi OS Setup (Windows)
echo ================================
echo.

REM Create virtual environment
echo Creating virtual environment...
python -m venv myai_env

REM Activate virtual environment
echo Activating virtual environment...
call myai_env\Scripts\activate.bat

REM Install dependencies
echo Installing dependencies...
pip install -r requirements.txt

echo.
echo ================================
echo Setup Complete!
echo ================================
echo.
echo Next steps:
echo 1. Set your API key:
echo    set GEMINI_API_KEY=AIzaSyBy4UZX_6sRTefTfl71qaTpQ1aSmLy2zrQIw
echo.
echo 2. Run MyAi OS:
echo    python -m myai_os.main_with_ui
echo.
pause
