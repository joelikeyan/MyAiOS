"""
myai/agents
-----------------

This subpackage contains a suite of lightweight agent stubs used by the
MyAi operating system.  Each agent encapsulates a specific domain of
functionality—listening to the user, planning tasks, reading the screen,
navigating the web, processing documents, interacting with the file system
and validating the results of actions.  These classes define a common
interface via a `handle_task` method.  In a complete implementation they
would integrate with audio pipelines, large language models, computer
vision and real user interfaces.  Here they provide simple skeletons
demonstrating the expected structure and behaviour.

The agents are:

* ``VoiceAgent`` – captures continuous speech and returns transcripts.
* ``PlanningAgent`` – converts high‑level intents into task lists for the
  bus to execute.
* ``VisionAgent`` – interprets UI elements and spatial context.
* ``BrowsingAgent`` – automates navigation of web interfaces.
* ``DocumentAgent`` – reads and extracts information from files.
* ``SystemControlAgent`` – performs mouse and keyboard actions.
* ``FileAgent`` – handles filesystem operations such as downloading and
  organising files.
* ``ValidationAgent`` – checks that tasks succeeded and reports errors.

Developers building on top of this package are expected to flesh out
these classes with actual functionality.  For example, the
``VoiceAgent`` might wrap a speech‑to‑text engine like Whisper, the
``PlanningAgent`` could integrate an LLM to generate plans and the
``VisionAgent`` might use computer vision models to locate buttons on
screen.  The current stubs simply log their actions to demonstrate
interaction with the bus.
"""

from .voice_agent import VoiceAgent
from .planning_agent import PlanningAgent
from .vision_agent import VisionAgent
from .browsing_agent import BrowsingAgent
from .document_agent import DocumentAgent
from .system_control_agent import SystemControlAgent
from .file_agent import FileAgent
from .validation_agent import ValidationAgent

__all__ = [
    "VoiceAgent",
    "PlanningAgent",
    "VisionAgent",
    "BrowsingAgent",
    "DocumentAgent",
    "SystemControlAgent",
    "FileAgent",
    "ValidationAgent",
]