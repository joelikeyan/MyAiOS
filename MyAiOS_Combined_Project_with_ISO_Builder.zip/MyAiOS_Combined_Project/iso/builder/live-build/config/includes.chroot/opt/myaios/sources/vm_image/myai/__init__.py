"""
MyAi package initializer.

This package provides the core classes and modules necessary to build
an AI‑native operating system.  The components included here are
organized into a MyAiBus orchestrator, a suite of specialized agents
and a minimal user interface layer.  Each module contains stub
implementations intended to be expanded into full functionality.
"""

from .myai_bus import MyAiBus
from .agents import (
    VoiceAgent,
    PlanningAgent,
    VisionAgent,
    BrowsingAgent,
    DocumentAgent,
    SystemControlAgent,
    FileAgent,
    ValidationAgent,
)
from .ui.desktop_shell import DesktopShell
from .ui.operator_panel import OperatorPanel

__all__ = [
    "MyAiBus",
    "VoiceAgent",
    "PlanningAgent",
    "VisionAgent",
    "BrowsingAgent",
    "DocumentAgent",
    "SystemControlAgent",
    "FileAgent",
    "ValidationAgent",
    "DesktopShell",
    "OperatorPanel",
]