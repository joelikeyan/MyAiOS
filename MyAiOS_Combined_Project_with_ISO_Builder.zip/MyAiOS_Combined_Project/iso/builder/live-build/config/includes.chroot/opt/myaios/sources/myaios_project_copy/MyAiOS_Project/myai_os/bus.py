import asyncio
import time
from typing import Dict, Callable, List
from dataclasses import dataclass
from enum import Enum


class EventType(Enum):
    INTENT_RECEIVED = "intent_received"
    PLAN_CREATED = "plan_created"
    STEP_EXECUTING = "step_executing"
    STEP_COMPLETED = "step_completed"
    VERIFICATION_PASSED = "verification_passed"
    VERIFICATION_FAILED = "verification_failed"
    TASK_COMPLETED = "task_completed"
    ERROR = "error"


@dataclass
class Event:
    type: EventType
    payload: Dict
    timestamp: float
    source: str


class MyAiBus:
    def __init__(self):
        self.subscribers: Dict[EventType, List[Callable]] = {}
        self.state = {}
        self.task_queue = asyncio.Queue()
        
    def subscribe(self, event_type: EventType, handler: Callable):
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        self.subscribers[event_type].append(handler)
        
    async def publish(self, event: Event):
        if event.type in self.subscribers:
            await asyncio.gather(*[
                handler(event) for handler in self.subscribers[event.type]
            ])
            
    async def process_intent(self, intent: str):
        event = Event(
            type=EventType.INTENT_RECEIVED,
            payload={"intent": intent},
            timestamp=time.time(),
            source="voice_input"
        )
        await self.publish(event)
        
    async def get_context(self):
        """Get current desktop context"""
        return {
            "active_window": "Browser",
            "installed_apps": ["Chrome", "Calculator", "Notepad"],
            "screen_size": "1920x1080"
        }


# Global bus instance
bus = MyAiBus()
