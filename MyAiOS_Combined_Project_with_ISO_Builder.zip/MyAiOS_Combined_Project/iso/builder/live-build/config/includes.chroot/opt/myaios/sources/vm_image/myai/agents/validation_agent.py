"""
validation_agent.py
-------------------

The ``ValidationAgent`` verifies that actions executed by other agents
succeeded as expected.  In a complete system this might check file
hashes, confirm UI state or validate that downloaded data matches a
schema.  The current stub simply returns success for any known task
and raises an error otherwise.
"""

from __future__ import annotations

from typing import Any, Dict

from myai.myai_bus import Task


class ValidationAgent:
    """Stub that validates the results of completed tasks."""

    def handle_task(self, task: Task) -> Dict[str, Any]:
        """Validate a result.

        Supported task name: ``validate`` with arbitrary parameters.

        Args:
            task: Task to validate.

        Returns:
            A dictionary indicating whether validation passed.
        """
        if task.name == "validate":
            return {"valid": True}
        raise ValueError(f"ValidationAgent cannot handle task '{task.name}'")