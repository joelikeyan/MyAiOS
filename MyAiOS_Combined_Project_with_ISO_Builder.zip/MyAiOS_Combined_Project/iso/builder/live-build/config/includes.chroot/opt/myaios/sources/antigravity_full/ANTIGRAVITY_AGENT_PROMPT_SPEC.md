System prompt + context injection + guardrails for MyAi OS desktop operator.
