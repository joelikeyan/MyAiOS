"""
Planner Agent - Decomposes intents into executable steps
"""

import asyncio
import json
from typing import List, Dict, Any
from dataclasses import dataclass

try:
    import anthropic
except ImportError:
    print("[WARNING] anthropic package not installed. Install with: pip install anthropic")
    anthropic = None

from myai_os.bus import MyAiBus, Event, EventType


@dataclass
class Step:
    order: int
    action: str
    parameters: Dict[str, Any]
    verification: str
    
    def to_dict(self):
        return {
            "order": self.order,
            "action": self.action,
            "parameters": self.parameters,
            "verification": self.verification
        }


class PlannerAgent:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        self.client = anthropic.Anthropic() if anthropic else None
        bus.subscribe(EventType.INTENT_RECEIVED, self.handle_intent)
        
    async def handle_intent(self, event: Event):
        """Handle incoming intent and create plan"""
        intent = event.payload["intent"]
        context = await self.bus.get_context()
        
        print(f"[PLANNER] Creating plan for: {intent}")
        
        try:
            plan = await self.create_plan(intent, context)
            
            await self.bus.publish(Event(
                type=EventType.PLAN_CREATED,
                payload={"plan": plan, "intent": intent},
                timestamp=asyncio.get_event_loop().time(),
                source="planner"
            ))
        except Exception as e:
            print(f"[PLANNER] Error: {e}")
            await self.bus.publish(Event(
                type=EventType.ERROR,
                payload={"error": str(e), "stage": "planning"},
                timestamp=asyncio.get_event_loop().time(),
                source="planner"
            ))
        
    async def create_plan(self, intent: str, context: Dict) -> List[Step]:
        """Generate execution plan using Claude"""
        
        if not self.client:
            # Fallback to simple parsing
            return self.create_simple_plan(intent)
            
        prompt = f"""You are a desktop automation planner.

User intent: {intent}

Current context:
- Active window: {context.get('active_window', 'Unknown')}
- Screen resolution: {context.get('screen_size', '1920x1080')}
- Operating system: Windows

Create an execution plan as JSON array. Each step must have:
- order: sequential number
- action: one of [open_application, click_element, type_text, press_keys, save_file, wait]
- parameters: dict of action parameters
- verification: how to confirm success

Example:
[
  {{
    "order": 1,
    "action": "open_application",
    "parameters": {{"app_name": "Notepad"}},
    "verification": "Window title contains 'Notepad'"
  }},
  {{
    "order": 2,
    "action": "type_text",
    "parameters": {{"text": "Hello World"}},
    "verification": "Text visible in editor"
  }}
]

Output ONLY valid JSON array, no explanation."""

        try:
            response = await asyncio.to_thread(
                self.client.messages.create,
                model="claude-sonnet-4-20250514",
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}]
            )
            
            plan_json = response.content[0].text
            plan_json = plan_json.strip()
            if plan_json.startswith("```"):
                plan_json = plan_json.split("```")[1]
                if plan_json.startswith("json"):
                    plan_json = plan_json[4:]
            
            plan_data = json.loads(plan_json)
            return [Step(**item) for item in plan_data]
            
        except Exception as e:
            print(f"[PLANNER] Claude API error: {e}")
            return self.create_simple_plan(intent)
    
    def create_simple_plan(self, intent: str) -> List[Step]:
        """Fallback simple plan generation"""
        intent_lower = intent.lower()
        
        if "calculator" in intent_lower or "calc" in intent_lower:
            return [
                Step(1, "open_application", {"app_name": "Calculator"}, 
                     "Calculator window visible")
            ]
        elif "notepad" in intent_lower or "note" in intent_lower:
            return [
                Step(1, "open_application", {"app_name": "Notepad"},
                     "Notepad window visible")
            ]
        else:
            return [
                Step(1, "open_application", {"app_name": "Explorer"},
                     "Explorer window visible")
            ]
