# MyAi OS Installation Script for Windows

# Create virtual environment
python -m venv myai_env

# Activate virtual environment
.\myai_env\Scripts\Activate.ps1

# Upgrade pip
python -m pip install --upgrade pip

# Install core dependencies
pip install anthropic
pip install pyautogui
pip install opencv-python
pip install pillow

# Install voice dependencies (optional)
pip install pvporcupine
pip install pyaudio
pip install faster-whisper

# Install Windows-specific dependencies
pip install pywin32
pip install psutil

# Create .env file template
@"
ANTHROPIC_API_KEY=your-api-key-here
"@ | Out-File -FilePath .env -Encoding UTF8

Write-Host ""
Write-Host "Installation complete!" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Edit .env file and add your Anthropic API key"
Write-Host "2. Run: python -m myai_os.main"
Write-Host ""
