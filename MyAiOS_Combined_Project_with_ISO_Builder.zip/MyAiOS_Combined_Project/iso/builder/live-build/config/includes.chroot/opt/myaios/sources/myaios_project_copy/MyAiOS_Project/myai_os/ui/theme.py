THEME = {
    "colors": {
        "bg_primary": "#1a2332",
        "bg_secondary": "#0d1621",
        "bg_control": "#2a3f5f",
        "accent_blue": "#4a9eff",
        "accent_active": "#2a5a8f",
        "success": "#4ade80",
        "error": "#ef4444",
        "warning": "#fbbf24",
        "text_primary": "#ffffff",
        "text_secondary": "#9db4d0",
        "text_muted": "#6b8cae"
    },
    "fonts": {
        "primary": ("Segoe UI", 10),
        "header": ("Segoe UI", 14, "bold"),
        "title": ("Segoe UI", 11),
        "small": ("Segoe UI", 9)
    },
    "spacing": {
        "padding_small": 5,
        "padding_medium": 10,
        "padding_large": 15
    }
}
