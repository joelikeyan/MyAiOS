"""
Folder Badge System - Visual markers for file operations
"""

import tkinter as tk
from PIL import Image, ImageDraw

from myai_os.ui.theme import THEME


class FolderBadgeSystem:
    def __init__(self):
        self.badges = {}
        
    def add_badge(self, x, y, badge_type):
        """
        Add badge overlay at position
        badge_type: 'success', 'error', 'pending'
        """
        colors = THEME["colors"]
        badge_window = tk.Toplevel()
        badge_window.attributes('-topmost', True)
        try:
            badge_window.attributes('-alpha', 0.9)
        except:
            pass
        badge_window.overrideredirect(True)
        
        # Badge symbol
        symbols = {
            'success': '✓',
            'error': '✕',
            'pending': '◷'
        }
        
        symbol_colors = {
            'success': colors["success"],
            'error': colors["error"],
            'pending': colors["warning"]
        }
        
        label = tk.Label(badge_window, 
                        text=symbols.get(badge_type, '•'),
                        bg=colors["bg_secondary"],
                        fg=symbol_colors.get(badge_type, 'white'),
                        font=("Segoe UI", 20, "bold"),
                        padx=10, pady=10)
        label.pack()
        
        badge_window.geometry(f"+{x}+{y}")
        self.badges[f"{x}_{y}"] = badge_window
        
        # Auto-dismiss after 3 seconds
        badge_window.after(3000, badge_window.destroy)
