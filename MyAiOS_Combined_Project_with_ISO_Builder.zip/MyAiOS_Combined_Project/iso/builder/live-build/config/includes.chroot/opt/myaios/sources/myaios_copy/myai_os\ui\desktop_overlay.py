"""
Desktop Overlay - Visual feedback on desktop
"""

import tkinter as tk
from threading import Thread
import time

from myai_os.bus import MyAiBus


class DesktopOverlay:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        self.overlays = []
        self.avatar = None
        
    def highlight_element(self, x, y, width, height):
        """Create glowing border around UI element"""
        overlay = tk.Toplevel()
        overlay.attributes('-topmost', True)
        try:
            overlay.attributes('-alpha', 0.3)
        except:
            pass
        overlay.overrideredirect(True)
        overlay.configure(bg='#4a9eff')
        
        # Position around element
        overlay.geometry(f"{width+10}x{height+10}+{x-5}+{y-5}")
        
        # Animate glow
        def pulse():
            for alpha in [0.3, 0.5, 0.7, 0.5, 0.3]:
                try:
                    overlay.attributes('-alpha', alpha)
                    overlay.update()
                except:
                    break
                time.sleep(0.1)
            overlay.destroy()
            
        Thread(target=pulse, daemon=True).start()
        
    def show_action_tooltip(self, text, x, y):
        """Show floating label near action"""
        tooltip = tk.Toplevel()
        tooltip.attributes('-topmost', True)
        try:
            tooltip.attributes('-alpha', 0.9)
        except:
            pass
        tooltip.overrideredirect(True)
        
        label = tk.Label(tooltip, text=f"▸ {text}", 
                        bg="#0d1621", fg="white",
                        font=("Segoe UI", 11),
                        padx=15, pady=8,
                        relief=tk.FLAT)
        label.pack()
        
        tooltip.geometry(f"+{x+20}+{y-30}")
        
        # Auto-dismiss after 2s
        tooltip.after(2000, tooltip.destroy)
        
    def show_agent_avatar(self):
        """Show holographic agent (placeholder)"""
        avatar = tk.Toplevel()
        avatar.attributes('-topmost', True)
        try:
            avatar.attributes('-alpha', 0.8)
        except:
            pass
        avatar.overrideredirect(True)
        avatar.configure(bg='#1a2332')
        
        # Placeholder agent visual
        canvas = tk.Canvas(avatar, width=150, height=300, 
                          bg='#1a2332', highlightthickness=0)
        canvas.create_text(75, 150, text="🤖\nMyAi", 
                          font=("Segoe UI", 24), fill="#4a9eff")
        canvas.pack()
        
        # Position in lower right
        try:
            screen_width = avatar.winfo_screenwidth()
            screen_height = avatar.winfo_screenheight()
            avatar.geometry(f"+{screen_width-200}+{screen_height-350}")
        except:
            avatar.geometry("+100+100")
        
        self.avatar = avatar
