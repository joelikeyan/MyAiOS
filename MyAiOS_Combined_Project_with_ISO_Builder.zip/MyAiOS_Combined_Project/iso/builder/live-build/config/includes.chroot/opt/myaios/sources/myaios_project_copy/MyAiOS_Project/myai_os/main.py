import asyncio

from myai_os.bus import MyAiBus
from myai_os.agents.planner import PlannerAgent
from myai_os.agents.executor import ExecutorAgent
from myai_os.agents.verifier import VerifierAgent
from myai_os.agents.memory import MemoryAgent
from myai_os.agents.context import ContextAgent
from myai_os.voice.listener import VoiceListener


async def main():
    print("=" * 60)
    print("MyAi OS - Console Mode")
    print("=" * 60)
    
    bus = MyAiBus()
    
    # Initialize agents
    print("Initializing agents...")
    planner = PlannerAgent(bus)
    executor = ExecutorAgent(bus)
    verifier = VerifierAgent(bus)
    memory = MemoryAgent(bus)
    context = ContextAgent(bus)
    
    # Start voice listener
    print("Starting voice listener...")
    listener = VoiceListener(bus)
    
    print("\nMyAi OS Started (Console Mode)")
    print("Type commands and press Enter")
    print("=" * 60)
    
    await listener.start()


if __name__ == "__main__":
    asyncio.run(main())
