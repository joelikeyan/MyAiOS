"""
myai_bus.py
-----------------

This module defines the core `MyAiBus` class used to orchestrate
communication between agents in the MyAi operating system.  The bus
maintains a task queue, dispatches tasks to the appropriate agent,
tracks the execution state and logs a trace of all actions.  It is
designed to be extended with real scheduling, concurrency and state
persistence.

The bus expects each agent to implement a `handle_task` method that
returns a result or raises an exception on failure.  Agents should be
registered with the bus before use.  A simple planning algorithm is
implemented in the PlanningAgent stub; in a full system this would
perform sophisticated intent parsing and graph construction.
"""

from __future__ import annotations

import queue
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class Task:
    """Represents a single action to be performed by an agent."""

    name: str
    params: Dict[str, Any] = field(default_factory=dict)
    agent: str = ""
    status: str = "pending"  # pending, running, success, failed
    result: Optional[Any] = None
    error: Optional[str] = None


class MyAiBus:
    """Central orchestrator connecting all MyAi agents."""

    def __init__(self, agents: Dict[str, Any]):
        """
        Initialize the bus with a dictionary of agents.  The keys should
        correspond to agent names used in Task.agent and the values should
        be instances of agent classes implementing `handle_task`.

        Args:
            agents: Mapping of agent name to agent instance.
        """
        self.agents = agents
        self.task_queue: queue.Queue[Task] = queue.Queue()
        self.trace: List[Task] = []

    def submit_tasks(self, tasks: List[Task]) -> None:
        """Add a list of tasks to the bus for execution."""
        for task in tasks:
            self.task_queue.put(task)

    def run(self) -> None:
        """
        Continuously process tasks in the queue.  This simple loop
        dispatches tasks sequentially; a full implementation would
        support parallelism and more sophisticated scheduling.
        """
        while not self.task_queue.empty():
            task = self.task_queue.get()
            agent = self.agents.get(task.agent)
            if not agent:
                task.status = "failed"
                task.error = f"Unknown agent: {task.agent}"
                self.trace.append(task)
                continue

            task.status = "running"
            try:
                result = agent.handle_task(task)
                task.status = "success"
                task.result = result
            except Exception as exc:
                task.status = "failed"
                task.error = str(exc)
            finally:
                self.trace.append(task)

    def get_trace(self) -> List[Task]:
        """
        Return the list of completed tasks for inspection.  The trace
        includes successful and failed tasks in the order they were
        executed.
        """
        return self.trace

    def reset_trace(self) -> None:
        """Clear the execution trace."""
        self.trace.clear()

    def process_request(self, request: str, planning_agent: Any) -> None:
        """
        High‑level convenience method.  Takes a user request and a
        PlanningAgent, generates tasks and runs them.  In a real
        implementation the planning agent would produce a graph of
        dependencies; here we assume a simple linear list.

        Args:
            request: Natural language request from the user.
            planning_agent: An agent capable of producing a task list
                from a request.
        """
        tasks = planning_agent.plan(request)
        self.submit_tasks(tasks)
        self.run()