import tkinter as tk
from PIL import Image, ImageDraw, ImageTk


class FolderBadgeSystem:
    def __init__(self):
        self.badges = {}
        
    def add_badge(self, folder_path, badge_type):
        """
        Add X or ✓ badge to folder icon
        badge_type: 'success', 'error', 'pending'
        """
        badge = self.create_badge_image(badge_type)
        self.create_floating_badge(badge, badge_type, folder_path)
        
    def create_badge_image(self, badge_type):
        size = 40
        img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        
        if badge_type == 'success':
            color = '#4ade80'
            draw.ellipse([0, 0, size, size], fill=color)
            draw.text((size//4, size//4), "✓", fill='white')
        elif badge_type == 'error':
            color = '#ef4444'
            draw.ellipse([0, 0, size, size], fill=color)
            draw.text((size//4, size//4), "✕", fill='white')
        else:
            color = '#fbbf24'
            draw.ellipse([0, 0, size, size], fill=color)
            
        return img
        
    def create_floating_badge(self, badge_img, badge_type, folder_path):
        badge_window = tk.Toplevel()
        badge_window.attributes('-topmost', True)
        badge_window.attributes('-alpha', 0.9)
        badge_window.overrideredirect(True)
        
        photo = ImageTk.PhotoImage(badge_img)
        label = tk.Label(badge_window, image=photo, bg='#1a2332')
        label.pack()
        
        # Position (simplified - would need window handle in production)
        x, y = 100, 100
        badge_window.geometry(f"+{x}+{y}")
        
        badge_window.image = photo
        self.badges[folder_path] = badge_window
