```mermaid
flowchart LR
MIC-->AEC-->VAD-->HWD
HWD--no-->IDLE
HWD--yes-->CAP-->ASR-->NLU-->PLAN-->ACT-->OBS
OBS--verify-->RESP-->IDLE
OBS--blocked-->REC-->PLAN
```
