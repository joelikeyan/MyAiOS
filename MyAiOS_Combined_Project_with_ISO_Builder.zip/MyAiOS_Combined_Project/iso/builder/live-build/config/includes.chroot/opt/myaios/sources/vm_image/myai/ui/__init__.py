"""
myai/ui
--------

This subpackage contains user interface components for the MyAi
operating system.  The UI layer is responsible for presenting the
3D spatial desktop and the operator panel that displays live
execution traces, file artifacts and settings.  These modules are
minimal skeletons: they define class signatures and document the
intended functionality without implementing any graphics or event
loop.  Developers should extend these classes using their preferred
GUI framework (e.g. PyQt, Godot) to build the actual visual
experience.
"""

from .desktop_shell import DesktopShell
from .operator_panel import OperatorPanel

__all__ = ["DesktopShell", "OperatorPanel"]