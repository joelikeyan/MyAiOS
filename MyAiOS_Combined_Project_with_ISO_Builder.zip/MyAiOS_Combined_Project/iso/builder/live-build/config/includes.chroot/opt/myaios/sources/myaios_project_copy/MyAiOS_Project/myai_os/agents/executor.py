import pyautogui
import asyncio
import time
from typing import Dict, List
from pathlib import Path
from myai_os.bus import MyAiBus, Event, EventType
from myai_os.agents.planner import Step


class ExecutorAgent:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        bus.subscribe(EventType.PLAN_CREATED, self.execute_plan)
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.5
        
    async def execute_plan(self, event: Event):
        plan = event.payload["plan"]
        
        for step in plan:
            await self.bus.publish(Event(
                type=EventType.STEP_EXECUTING,
                payload={"step": step},
                timestamp=time.time(),
                source="executor"
            ))
            
            result = await self.execute_step(step)
            
            await self.bus.publish(Event(
                type=EventType.STEP_COMPLETED,
                payload={"step": step, "result": result},
                timestamp=time.time(),
                source="executor"
            ))
            
    async def execute_step(self, step: Step) -> Dict:
        action_map = {
            "open_application": self.open_application,
            "click_element": self.click_element,
            "type_text": self.type_text,
            "press_keys": self.press_keys,
            "save_file": self.save_file
        }
        
        handler = action_map.get(step.action)
        if not handler:
            raise ValueError(f"Unknown action: {step.action}")
            
        screenshot_before = pyautogui.screenshot()
        result = await handler(**step.parameters)
        screenshot_after = pyautogui.screenshot()
        
        return {
            "success": result,
            "screenshot_before": screenshot_before,
            "screenshot_after": screenshot_after
        }
        
    async def open_application(self, app_name: str) -> bool:
        """Open application using Windows Start menu"""
        pyautogui.press('win')
        await asyncio.sleep(0.5)
        pyautogui.write(app_name, interval=0.05)
        await asyncio.sleep(0.5)
        pyautogui.press('enter')
        await asyncio.sleep(2)
        return True
        
    async def click_element(self, description: str = "", x: int = 0, y: int = 0) -> bool:
        """Click at specific coordinates"""
        pyautogui.click(x, y)
        await asyncio.sleep(0.3)
        return True
        
    async def type_text(self, text: str, field_description: str = None) -> bool:
        """Type text into focused field"""
        pyautogui.write(text, interval=0.05)
        return True
        
    async def press_keys(self, keys: List[str]) -> bool:
        """Press keyboard shortcuts"""
        pyautogui.hotkey(*keys)
        return True
        
    async def save_file(self, path: str) -> bool:
        """Save file using Ctrl+S and filename"""
        pyautogui.hotkey('ctrl', 's')
        await asyncio.sleep(0.5)
        pyautogui.write(path, interval=0.05)
        pyautogui.press('enter')
        await asyncio.sleep(1)
        return True
