"""
vision_agent.py
----------------

This module defines the ``VisionAgent`` responsible for interpreting the
graphical user interface.  In a fully fledged MyAi system this agent
would capture screenshots, locate UI elements via computer vision and
relay spatial information to other components.  For this example the
agent simply acknowledges tasks and returns dummy coordinates.
"""

from __future__ import annotations

from typing import Dict, Any

from myai.myai_bus import Task


class VisionAgent:
    """Stub that simulates visual perception of the desktop UI."""

    def handle_task(self, task: Task) -> Dict[str, Any]:
        """Return dummy element locations or raise on unknown tasks.

        Args:
            task: Task with name ``locate_element``.

        Returns:
            A dictionary representing the position and size of the
            located element.
        """
        if task.name == "locate_element":
            # In a real system this would analyse the screen and return
            # bounding boxes.  Here we return a fixed coordinate.
            element_id = task.params.get("element_id", "unknown")
            return {"element_id": element_id, "x": 100, "y": 200, "width": 50, "height": 20}
        raise ValueError(f"VisionAgent cannot handle task '{task.name}'")