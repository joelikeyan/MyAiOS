# MyAi OS

Self-hosted, voice-first, agent-orchestrated AI-native OS that operates a real Linux desktop in Docker and verifies outcomes with artifacts.

Quick start:
- cp .env.example .env
- docker compose up --build
- UI: http://localhost:3000
- Desktop: http://localhost:6080
- Agent: http://localhost:8080/health
- Voice: http://localhost:7070/health
