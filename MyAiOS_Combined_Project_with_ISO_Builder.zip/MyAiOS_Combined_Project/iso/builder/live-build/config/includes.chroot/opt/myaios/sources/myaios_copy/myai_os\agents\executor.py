"""
Executor Agent - Executes atomic UI/system actions
"""

import asyncio
import time
import subprocess
from pathlib import Path
from typing import Dict, Any

try:
    import pyautogui
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.5
except ImportError:
    print("[WARNING] pyautogui not installed. Install with: pip install pyautogui")
    pyautogui = None

from myai_os.bus import MyAiBus, Event, EventType
from myai_os.agents.planner import Step


class ExecutorAgent:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        bus.subscribe(EventType.PLAN_CREATED, self.execute_plan)
        
    async def execute_plan(self, event: Event):
        """Execute all steps in the plan"""
        plan = event.payload["plan"]
        
        print(f"[EXECUTOR] Starting plan execution: {len(plan)} steps")
        
        for step in plan:
            await self.bus.publish(Event(
                type=EventType.STEP_EXECUTING,
                payload={"step": step},
                timestamp=time.time(),
                source="executor"
            ))
            
            try:
                result = await self.execute_step(step)
                
                await self.bus.publish(Event(
                    type=EventType.STEP_COMPLETED,
                    payload={"step": step, "result": result},
                    timestamp=time.time(),
                    source="executor"
                ))
            except Exception as e:
                print(f"[EXECUTOR] Step failed: {e}")
                await self.bus.publish(Event(
                    type=EventType.ERROR,
                    payload={"error": str(e), "step": step},
                    timestamp=time.time(),
                    source="executor"
                ))
                break
                
    async def execute_step(self, step: Step) -> Dict[str, Any]:
        """Execute a single step"""
        action_map = {
            "open_application": self.open_application,
            "click_element": self.click_element,
            "type_text": self.type_text,
            "press_keys": self.press_keys,
            "save_file": self.save_file,
            "wait": self.wait
        }
        
        handler = action_map.get(step.action)
        if not handler:
            raise ValueError(f"Unknown action: {step.action}")
        
        print(f"[EXECUTOR] Executing: {step.action}")
        
        screenshot_before = None
        screenshot_after = None
        
        if pyautogui:
            screenshot_before = pyautogui.screenshot()
        
        result = await handler(**step.parameters)
        
        if pyautogui:
            screenshot_after = pyautogui.screenshot()
        
        return {
            "success": result,
            "screenshot_before": screenshot_before,
            "screenshot_after": screenshot_after
        }
    
    async def open_application(self, app_name: str) -> bool:
        """Open application via Windows Start menu"""
        try:
            if pyautogui:
                # Press Windows key
                pyautogui.press('win')
                await asyncio.sleep(0.5)
                
                # Type app name
                pyautogui.typewrite(app_name, interval=0.05)
                await asyncio.sleep(0.5)
                
                # Press Enter
                pyautogui.press('enter')
                await asyncio.sleep(2)
            else:
                # Fallback to subprocess
                subprocess.Popen(f"start {app_name}", shell=True)
                await asyncio.sleep(2)
            
            return True
        except Exception as e:
            print(f"[EXECUTOR] Error opening {app_name}: {e}")
            return False
    
    async def click_element(self, x: int, y: int, description: str = "") -> bool:
        """Click at coordinates"""
        if not pyautogui:
            return False
            
        try:
            pyautogui.click(x, y)
            await asyncio.sleep(0.3)
            return True
        except Exception as e:
            print(f"[EXECUTOR] Click error: {e}")
            return False
    
    async def type_text(self, text: str, field_description: str = None) -> bool:
        """Type text via keyboard"""
        if not pyautogui:
            return False
            
        try:
            pyautogui.typewrite(text, interval=0.05)
            return True
        except Exception as e:
            # Fallback for special characters
            try:
                for char in text:
                    pyautogui.press(char)
                    await asyncio.sleep(0.05)
                return True
            except:
                print(f"[EXECUTOR] Type error: {e}")
                return False
    
    async def press_keys(self, keys: list) -> bool:
        """Press key combination"""
        if not pyautogui:
            return False
            
        try:
            pyautogui.hotkey(*keys)
            await asyncio.sleep(0.2)
            return True
        except Exception as e:
            print(f"[EXECUTOR] Key press error: {e}")
            return False
    
    async def save_file(self, path: str) -> bool:
        """Save file using Ctrl+S and dialog"""
        try:
            # Ctrl+S
            await self.press_keys(['ctrl', 's'])
            await asyncio.sleep(0.5)
            
            # Type file path
            await self.type_text(path)
            await asyncio.sleep(0.3)
            
            # Press Enter
            if pyautogui:
                pyautogui.press('enter')
            
            await asyncio.sleep(0.5)
            return True
        except Exception as e:
            print(f"[EXECUTOR] Save error: {e}")
            return False
    
    async def wait(self, seconds: float) -> bool:
        """Wait for specified time"""
        await asyncio.sleep(seconds)
        return True
