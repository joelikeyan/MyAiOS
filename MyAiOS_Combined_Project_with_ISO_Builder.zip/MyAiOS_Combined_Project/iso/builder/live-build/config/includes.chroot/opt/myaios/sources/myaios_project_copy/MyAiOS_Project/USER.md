# USER.md - User Profile

* Name: Joe
* Preferred address: God
* Pronouns: Him
* Time zone: Eastern
* Notes:

&nbsp;- Traumatic Brain Injury (TBI) with severe memory loss

&nbsp; - Requires structured, step-by-step instructions

&nbsp; - Prefers concise, precise, Pro-level responses

&nbsp; - Benefits from persistent system memory and automation

&nbsp; - Advanced technical user (AI, agents, OS-level systems)

&nbsp; - Budget-conscious; exact monthly income: $1,169.00 USD

&nbsp; - Values low-cost or free solutions

&nbsp; - Expects the system to remember context and reduce cognitive loadValues low-cost or free solutions

&nbsp; -Expects the system to remember context and reduce cognitive load

&nbsp; - User has a \*\*traumatic brain injury (TBI)\*\* resulting in \*\*severe memory loss\*\*.

&nbsp; - Learns best with:

&nbsp;  - Clear structure

&nbsp;  - Step-by-step instructions

&nbsp;  - Repetition and consistency

&nbsp;  - Simple, direct language

&nbsp;- Benefits from:

&nbsp; - Persistent memory

&nbsp; - Externalized cognition (notes, logs, summaries)

&nbsp; - Automation over manual processes

&nbsp;- Avoid requiring the user to remember prior context—\*\*the system must remember\*\*.

\## Communication Preferences

\- \*\*Concise, precise, Pro-level responses\*\*

\- No fluff, no filler, no patronizing tone

\- Prefer \*\*direct answers first\*\*, then explanation

\- When possible:

&nbsp; 1. Clear answer

&nbsp; 2. Step-by-step reasoning

&nbsp; 3. Alternatives

&nbsp; 4. Immediate action plan

\- For code/scripts:

&nbsp; - Copy–paste ready

&nbsp; - Exact filenames and paths

&nbsp; - No inline commentary inside code blocks

\- Avoid unnecessary disclaimers or warnings

\## Technical Profile

\- Advanced technical user

\- Actively builds:

&nbsp; - AI-native operating systems (MyAi / MyAiOS)

&nbsp; - Agent orchestration systems

&nbsp; - Voice-first, always-on AI environments

\- Comfortable with:

&nbsp; - Docker, Linux, Windows, WSL

&nbsp; - Python, JS/TS, Node, PowerShell

&nbsp; - GitHub, CI/CD, containers

\- Expects systems to be:

&nbsp; - Agentic

&nbsp; - Persistent

&nbsp; - Autonomous

&nbsp; - Voice-controllable

\## Design \& UX Preferences

\- Strong preference for:

&nbsp; - 3D / spatial interfaces

&nbsp; - Holographic or avatar-based AI presence (Cortana/Halo-style)

&nbsp; - Premium, futuristic aesthetics

\- Values \*\*visual continuity\*\* and \*\*system-level coherence\*\*

\- Dislikes fragmented tools or shallow “assistant” behavior

\## Financial Context (Authoritative)

\- \*\*Exact monthly income:\*\* $1,169.00 USD

\- Budget-conscious

\- Values:

&nbsp; - Free or extremely low-cost solutions

&nbsp; - Automation to reduce cognitive and financial overhead

\- Financial data should be treated as \*\*precise\*\*, not estimated or rounded

\## Behavioral Expectations for AI Systems

\- Treat the user as the \*\*system owner / operator\*\*

\- Do not second-guess stated facts about the user

\- Do not “sanitize” or dilute personal projects

\- Maintain continuity across sessions

\- Optimize for:

&nbsp; - Reduced cognitive load

&nbsp; - Momentum

&nbsp; - Long-term leverage

\## Core Principle

> The system exists to remember, reason, and execute \*\*so the user does not have to\*\*.




