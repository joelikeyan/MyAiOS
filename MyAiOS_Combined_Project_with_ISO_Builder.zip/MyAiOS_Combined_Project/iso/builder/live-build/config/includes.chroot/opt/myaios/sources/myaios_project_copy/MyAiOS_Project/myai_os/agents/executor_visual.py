import pyautogui
import asyncio
from myai_os.agents.executor import ExecutorAgent
from myai_os.agents.planner import Step


class VisualExecutor(ExecutorAgent):
    def __init__(self, bus, overlay):
        super().__init__(bus)
        self.overlay = overlay
        
    async def execute_step(self, step: Step):
        # Show action tooltip
        x, y = pyautogui.position()
        self.overlay.show_action_tooltip(step.action, x, y)
        
        # Execute with highlighting
        if "click" in step.action:
            target_x = step.parameters.get("x", x)
            target_y = step.parameters.get("y", y)
            self.overlay.highlight_element(target_x, target_y, 100, 40)
            await asyncio.sleep(0.5)
            
        result = await super().execute_step(step)
        
        return result
