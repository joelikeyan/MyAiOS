import asyncio
import tkinter as tk
from threading import Thread

from myai_os.bus import MyAiBus
from myai_os.agents.planner import PlannerAgent
from myai_os.agents.executor_visual import VisualExecutor
from myai_os.agents.verifier import VerifierAgent
from myai_os.agents.memory import MemoryAgent
from myai_os.agents.context import ContextAgent
from myai_os.ui.operator_window import OperatorWindow
from myai_os.ui.desktop_overlay import DesktopOverlay
from myai_os.ui.folder_badges import FolderBadgeSystem
from myai_os.voice.listener import VoiceListener


def run_ui(window):
    """Run UI in separate thread"""
    window.run()


async def main():
    print("=" * 60)
    print("MyAi OS - Voice-First Agent-Orchestrated System")
    print("=" * 60)
    
    # Create bus
    bus = MyAiBus()
    
    # Create UI components
    print("Initializing UI...")
    operator_window = OperatorWindow(bus)
    overlay = DesktopOverlay(bus)
    badges = FolderBadgeSystem()
    
    # Initialize agents with UI
    print("Initializing agents...")
    planner = PlannerAgent(bus)
    executor = VisualExecutor(bus, overlay)
    verifier = VerifierAgent(bus)
    memory = MemoryAgent(bus)
    context = ContextAgent(bus)
    
    # Show agent avatar
    print("Showing agent avatar...")
    overlay.show_agent_avatar()
    
    # Add initial step
    operator_window.add_step("System ready", "complete")
    
    # Run UI in separate thread
    print("Starting UI...")
    ui_thread = Thread(target=run_ui, args=(operator_window,), daemon=True)
    ui_thread.start()
    
    # Start voice listener
    print("Starting voice listener...")
    listener = VoiceListener(bus, wake_word="computer")
    
    print("\nMyAi OS is running!")
    print("Type commands or say 'Computer' followed by your command")
    print("=" * 60)
    
    await listener.start()


if __name__ == "__main__":
    asyncio.run(main())
