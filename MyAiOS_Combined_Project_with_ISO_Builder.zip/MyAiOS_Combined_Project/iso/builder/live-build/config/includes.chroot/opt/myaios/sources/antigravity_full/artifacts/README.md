Store evidence here: logs, screenshots, reports.
