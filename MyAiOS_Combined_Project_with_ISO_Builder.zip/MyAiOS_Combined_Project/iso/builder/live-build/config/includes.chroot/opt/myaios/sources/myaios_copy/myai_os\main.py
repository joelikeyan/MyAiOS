"""
MyAi OS - Main Entry Point
Voice-first, agent-orchestrated desktop automation system
"""

import asyncio
from threading import Thread

from myai_os.bus import MyAiBus
from myai_os.agents.planner import PlannerAgent
from myai_os.agents.executor import ExecutorAgent
from myai_os.agents.verifier import VerifierAgent
from myai_os.agents.memory import MemoryAgent
from myai_os.agents.context import ContextAgent
from myai_os.ui.operator_window import OperatorWindow
from myai_os.voice.listener import VoiceListener


def run_ui(window):
    """Run UI in separate thread"""
    window.run()


async def main():
    """Initialize and start MyAi OS"""
    print("=" * 60)
    print("MyAi OS - AI-Native Operating System")
    print("=" * 60)
    
    # Create event bus
    bus = MyAiBus()
    
    # Initialize agents
    print("[SYSTEM] Initializing agents...")
    planner = PlannerAgent(bus)
    executor = ExecutorAgent(bus)
    verifier = VerifierAgent(bus)
    memory = MemoryAgent(bus, storage_path="myai_memory.json")
    context = ContextAgent(bus)
    
    print("[SYSTEM] Agents ready")
    
    # Create UI
    print("[SYSTEM] Starting operator window...")
    operator_window = OperatorWindow(bus)
    
    # Add initial step
    operator_window.add_step("System initialized", "complete")
    
    # Run UI in separate thread
    ui_thread = Thread(target=run_ui, args=(operator_window,), daemon=True)
    ui_thread.start()
    
    # Start voice listener (blocking)
    print("[SYSTEM] Starting voice listener...")
    listener = VoiceListener(bus, wake_word="computer")
    await listener.start()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[SYSTEM] Shutting down MyAi OS...")
    except Exception as e:
        print(f"[SYSTEM] Error: {e}")
        import traceback
        traceback.print_exc()
