cp .env.example .env; docker compose up --build; verify UI/desktop/health; write artifacts/boot_report.md.
