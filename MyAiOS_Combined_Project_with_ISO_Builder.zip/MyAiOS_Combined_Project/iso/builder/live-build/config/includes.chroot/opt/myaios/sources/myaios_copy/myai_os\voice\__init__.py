"""
MyAi OS Voice Components
"""

from myai_os.voice.listener import VoiceListener

__all__ = ['VoiceListener']
