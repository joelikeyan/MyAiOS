from fastapi import FastAPI
import os
app = FastAPI()
@app.get("/health")
def health():
    return {"ok": True, "wake_word": os.getenv("WAKE_WORD", "hey myai")}
@app.get("/")
def root():
    return {"service": "myai-voice", "status": "scaffold"}
