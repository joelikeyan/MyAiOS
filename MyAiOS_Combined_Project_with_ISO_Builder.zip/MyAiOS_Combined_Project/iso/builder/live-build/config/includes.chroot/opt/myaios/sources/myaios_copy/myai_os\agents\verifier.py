"""
Verifier Agent - Confirms actions succeeded
"""

import asyncio
from typing import Dict, Any
from pathlib import Path

try:
    import anthropic
except ImportError:
    anthropic = None

from myai_os.bus import MyAiBus, Event, EventType
from myai_os.agents.planner import Step


class VerifierAgent:
    def __init__(self, bus: MyAiBus):
        self.bus = bus
        self.client = anthropic.Anthropic() if anthropic else None
        bus.subscribe(EventType.STEP_COMPLETED, self.verify_step)
        
    async def verify_step(self, event: Event):
        """Verify a completed step"""
        step = event.payload["step"]
        result = event.payload["result"]
        
        print(f"[VERIFIER] Verifying: {step.action}")
        
        try:
            verified = await self.verify(step, result)
            
            event_type = (EventType.VERIFICATION_PASSED if verified 
                         else EventType.VERIFICATION_FAILED)
            
            await self.bus.publish(Event(
                type=event_type,
                payload={"step": step, "verified": verified},
                timestamp=asyncio.get_event_loop().time(),
                source="verifier"
            ))
            
        except Exception as e:
            print(f"[VERIFIER] Error: {e}")
            await self.bus.publish(Event(
                type=EventType.ERROR,
                payload={"error": str(e), "stage": "verification"},
                timestamp=asyncio.get_event_loop().time(),
                source="verifier"
            ))
    
    async def verify(self, step: Step, result: Dict[str, Any]) -> bool:
        """Perform verification based on step type"""
        verification = step.verification.lower()
        
        # Visual verification using Claude
        if "screenshot_after" in result and result["screenshot_after"]:
            return await self.verify_visual(step.verification, result["screenshot_after"])
        
        # File system verification
        if "file" in verification or "save" in verification:
            return await self.verify_file(step.parameters.get("path", ""))
        
        # Window verification
        if "window" in verification or "open" in verification:
            return await self.verify_window(step.parameters.get("app_name", ""))
        
        # Default to success if no specific verification
        return result.get("success", False)
    
    async def verify_visual(self, expected: str, screenshot) -> bool:
        """Verify using visual analysis with Claude"""
        if not self.client or not screenshot:
            return True  # Assume success if no verification possible
        
        try:
            import base64
            from io import BytesIO
            
            buffer = BytesIO()
            screenshot.save(buffer, format="PNG")
            image_data = base64.b64encode(buffer.getvalue()).decode()
            
            response = await asyncio.to_thread(
                self.client.messages.create,
                model="claude-sonnet-4-20250514",
                max_tokens=100,
                messages=[{
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": image_data
                            }
                        },
                        {
                            "type": "text",
                            "text": f"Does this screenshot show: {expected}\nRespond ONLY: YES or NO"
                        }
                    ]
                }]
            )
            
            return "YES" in response.content[0].text.upper()
        except Exception as e:
            print(f"[VERIFIER] Visual verification error: {e}")
            return True
    
    async def verify_file(self, path: str) -> bool:
        """Verify file exists"""
        if not path:
            return True
        
        try:
            file_path = Path(path).expanduser()
            exists = file_path.exists()
            if exists:
                print(f"[VERIFIER] File verified: {path}")
            else:
                print(f"[VERIFIER] File not found: {path}")
            return exists
        except Exception as e:
            print(f"[VERIFIER] File check error: {e}")
            return False
    
    async def verify_window(self, app_name: str) -> bool:
        """Verify window/application is open"""
        try:
            import win32gui
            
            def enum_windows_callback(hwnd, windows):
                if win32gui.IsWindowVisible(hwnd):
                    window_title = win32gui.GetWindowText(hwnd)
                    windows.append(window_title)
            
            windows = []
            win32gui.EnumWindows(enum_windows_callback, windows)
            
            # Check if app name appears in any window title
            for window in windows:
                if app_name.lower() in window.lower():
                    print(f"[VERIFIER] Window verified: {window}")
                    return True
            
            print(f"[VERIFIER] Window not found: {app_name}")
            return False
        except:
            # Fallback: assume success if can't verify
            return True
