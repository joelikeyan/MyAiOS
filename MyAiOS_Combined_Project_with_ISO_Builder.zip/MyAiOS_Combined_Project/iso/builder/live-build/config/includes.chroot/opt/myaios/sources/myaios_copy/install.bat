@echo off
echo ============================================
echo MyAi OS Installation Script for Windows
echo ============================================
echo.

echo Creating virtual environment...
python -m venv myai_env
if errorlevel 1 (
    echo ERROR: Failed to create virtual environment
    pause
    exit /b 1
)

echo.
echo Activating virtual environment...
call myai_env\Scripts\activate.bat

echo.
echo Installing dependencies...
pip install --upgrade pip
pip install -r requirements.txt

echo.
echo ============================================
echo Installation complete!
echo ============================================
echo.
echo Next steps:
echo 1. Set your API key: set ANTHROPIC_API_KEY=your-key-here
echo 2. Run basic mode: python -m myai_os.main
echo 3. Run with UI: python -m myai_os.main_with_ui
echo.
pause
