# MyAi OS - AI-Native Operating System

![MyAi OS](docs/logo.png)

MyAi OS is a voice-first, agent-orchestrated desktop automation system that transforms your computer into an AI-native workspace.

## Features

- 🎤 **Voice-First Interface** - Wake word activation ("Computer...")
- 🤖 **Multi-Agent Architecture** - Planner, Executor, Verifier, Memory, Context agents
- 👁️ **Visual Verification** - AI-powered screenshot analysis
- 🔄 **Real Automation** - Actual mouse, keyboard, and application control
- 📊 **Live Monitoring** - Real-time step tracking in operator window
- 💾 **Persistent Memory** - Learns from your workflows

## Quick Start

### Prerequisites

- Windows 10/11
- Python 3.8+
- Anthropic API key ([Get one here](https://console.anthropic.com/))

### Installation

1. **Clone or download** this repository

2. **Run installation script**:
   ```powershell
   .\install.ps1
   ```

3. **Add your API key**:
   Edit `.env` file:
   ```
   ANTHROPIC_API_KEY=sk-ant-...
   ```

4. **Run MyAi OS**:
   ```powershell
   .\myai_env\Scripts\Activate.ps1
   python -m myai_os.main
   ```

## Usage

### Voice Commands

Say "**Computer**" followed by your command:

- "Computer, open calculator"
- "Computer, create a budget spreadsheet"
- "Computer, organize my downloads folder"

### Demo Mode

If voice input isn't available, MyAi OS runs in demo mode where you can type commands directly.

## Architecture

```
┌─────────────────────────────────────┐
│         Voice Interface             │
└────────────┬────────────────────────┘
             │
┌────────────▼────────────────────────┐
│          MyAi Bus                   │
│    (Event Orchestrator)             │
└─┬──────┬────────┬────────┬─────────┘
  │      │        │        │
┌─▼──┐ ┌▼───┐ ┌──▼──┐ ┌───▼──┐
│Plan│ │Exec│ │Vrfy │ │Memory│
└────┘ └────┘ └─────┘ └──────┘
```

### Agents

- **Planner**: Decomposes intents into steps
- **Executor**: Controls mouse, keyboard, apps
- **Verifier**: Confirms actions succeeded
- **Memory**: Tracks patterns and context
- **Context**: Monitors desktop state

## Configuration

Edit `myai_os/ui/theme.py` to customize colors and fonts.

## Troubleshooting

### Voice input not working
- Check microphone permissions
- Install: `pip install pvporcupine pyaudio`
- Use demo mode (type commands)

### API errors
- Verify your Anthropic API key in `.env`
- Check API quota at console.anthropic.com

### Automation fails
- Run as Administrator for full control
- Check antivirus/security software
- Disable "Failsafe" in code if needed

## Project Structure

```
MyAiOS/
├── myai_os/
│   ├── agents/          # AI agents
│   ├── ui/              # Operator window
│   ├── voice/           # Voice input
│   ├── bus.py           # Event system
│   └── main.py          # Entry point
├── assets/              # UI assets
├── install.ps1          # Setup script
└── requirements.txt     # Dependencies
```

## Contributing

This is an experimental project. Contributions welcome!

## License

MIT License - See LICENSE file

## Safety & Disclaimer

MyAi OS controls your mouse and keyboard. Always:
- Test in a safe environment first
- Review generated plans before execution
- Keep Failsafe enabled (move mouse to corner to stop)
- Use at your own risk

## Support

For issues and questions, please open a GitHub issue.

---

Built with Claude by Anthropic 🤖
