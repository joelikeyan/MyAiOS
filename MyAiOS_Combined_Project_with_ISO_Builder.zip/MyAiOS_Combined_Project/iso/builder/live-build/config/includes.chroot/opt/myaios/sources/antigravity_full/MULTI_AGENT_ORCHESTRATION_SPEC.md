Agents: voice session, perception, planner, executor, verifier, memory. Flow: wake→perception→plan→execute→verify→replan/stop.
