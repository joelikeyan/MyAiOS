# MyAi OS Virtual Machine Image

This package contains the source code for MyAi OS along with a
`Vagrantfile` to build a virtual machine image on your own machine.  The
VM uses Ubuntu 20.04 as its base, installs Python and all required
dependencies, and sets up a virtual environment with MyAi OS ready to
run.  Vagrant makes it easy to create reproducible VM images using
VirtualBox (or another provider).

## Prerequisites

- [Vagrant](https://www.vagrantup.com/) 2.3+
- [VirtualBox](https://www.virtualbox.org/) 6.1+ (or another Vagrant provider)
- An Anthropic API key (required at runtime)

## Getting Started

1. **Extract this zip file** somewhere on your host machine.

2. **Open a terminal** and navigate to the extracted folder:

   ```bash
   cd path/to/extracted/folder
   ```

3. **Start the VM**:

   ```bash
   vagrant up
   ```

   Vagrant will download the base box (Ubuntu 20.04), install Python,
   create a virtual environment, install dependencies, and prepare a
   wrapper script to run MyAi OS.

4. **Launch MyAi OS**:

   ```bash
   vagrant ssh -c '/home/vagrant/run_myai.sh'
   ```

   Before running, you should set your Anthropic API key inside the VM:

   ```bash
   vagrant ssh
   echo 'export ANTHROPIC_API_KEY=sk-ant-your-key' >> ~/.bashrc
   exit
   ```

5. **Develop**: The `synced_folder` directive in the Vagrantfile mounts
   the host project folder into `/home/vagrant/MyAi` in the VM.  Edits
   to the code on the host machine are immediately visible in the VM.

## Contents

- `Vagrantfile` – Defines the VM configuration and provisioning steps
- `run_myai.sh` – Generated at provisioning time; starts MyAi OS
- `myai` – Python package implementing MyAi OS
- Other supporting files (install scripts, assets, docs, etc.)

Feel free to modify the Vagrantfile to change the base box, CPU/memory
settings, or provisioning steps.  Enjoy exploring your AI‑native desktop
experience inside a virtual machine!
