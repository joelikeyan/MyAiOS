#!/bin/bash

echo "============================================"
echo "MyAi OS Installation Script"
echo "============================================"
echo ""

echo "Creating virtual environment..."
python3 -m venv myai_env
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to create virtual environment"
    exit 1
fi

echo ""
echo "Activating virtual environment..."
source myai_env/bin/activate

echo ""
echo "Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "============================================"
echo "Installation complete!"
echo "============================================"
echo ""
echo "Next steps:"
echo "1. Set your API key: export ANTHROPIC_API_KEY='your-key-here'"
echo "2. Run basic mode: python -m myai_os.main"
echo "3. Run with UI: python -m myai_os.main_with_ui"
echo ""
