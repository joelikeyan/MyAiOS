# MyAi OS — Combined Project Bundle

This bundle combines four uploaded project zips into a single, organized workspace.

## What's inside

- `sources/antigravity_full/` — Antigravity agent-mode specs + docker assets
- `sources/vm_image/` — VM-focused starter project (batch scripts, myai package)
- `sources/myaios_copy/` — MyAi OS Python app scaffold + assets
- `sources/myaios_project_copy/` — Larger MyAiOS_Project workspace (venv + caches removed)

## How to use

Start by choosing the codebase you want to run first:

### Option 1: Run the VM starter
1. Open `sources/vm_image/README_vm.md`
2. Use `start.bat` or `run.bat`

### Option 2: Run the MyAi OS scaffold
1. Open `sources/myaios_copy/SETUP_GUIDE.md`
2. Run `myai_os/main_with_ui.py` (see the guide)

### Option 3: Use Antigravity agent mode
1. Open `sources/antigravity_full/AGENTS.md`
2. Use the prompt spec in `ANTIGRAVITY_AGENT_PROMPT_SPEC.md`

## Notes

- I did **not** attempt to auto-merge code across these repositories because that can silently break imports and build pipelines.
- I removed Python virtualenv folders and bytecode caches from `myaios_project_copy` to keep the bundle portable.

